import { useState } from 'react';
import { AxiosHttpPayload, HttpClient } from '../http';
import { APIset } from './api.propTypes';

export const useAPIMutation = (apiSet: APIset): any => {
	const [data, setData] = useState(null);
	const [error, setError] = useState(null);
	const [loaded, setLoaded] = useState(false);

	const promiseAPI = (payload: AxiosHttpPayload): Promise<any> => {
		const apiPayLoad: AxiosHttpPayload = {};
		if (payload?.data) {
			apiPayLoad.data = payload.data;
		}

		if (payload?.paramsData) {
			apiPayLoad.paramsData = payload.paramsData;
		}

		if (payload?.queryParams) {
			apiPayLoad.queryParams = payload.queryParams;
		}
		let promise;
		switch (apiSet.method) {
			case 'GET': {
				promise = HttpClient.get(apiSet.url, apiPayLoad);
				break;
			}
			case 'POST': {
				promise = HttpClient.post(apiSet.url, apiPayLoad);
				break;
			}
			case 'PUT': {
				promise = HttpClient.put(apiSet.url, apiPayLoad);
				break;
			}
			case 'PATCH': {
				promise = HttpClient.patch(apiSet.url, apiPayLoad);
				break;
			}
			case 'DELETE': {
				promise = HttpClient.delete(apiSet.url, apiPayLoad);
				break;
			}
			default: {
				promise = HttpClient.get(apiSet.url, apiPayLoad);
				break;
			}
		}
		return promise;
	};

	const invokeAPI = (payload: AxiosHttpPayload): Promise<any> => {
		setLoaded(true);
		const promise = promiseAPI(payload);
		promise.then((res: any) => {
			setData(res.data);
		})
		.catch((error_) => {
			setError(error_);
		}).finally(() => {
			setLoaded(false);
		});
		return promise;
	};

	return [invokeAPI, { isLoading: loaded, error, data }];
};