import { useState } from 'react';
import { HttpClient } from '../http';
import { useLocalStorage } from 'usehooks-ts';
import { AuthSignupAPIPayload, LoginPayload, RegisterUserPayload, ResetPasswordPayload, UserDetails, ServeParticipantPayload, ContactPreferencesPayload } from '../models/auth.models';
// import { Utils } from '../shared';
import { API } from '../shared/constants/api.constants';
import { ApiProps, ApiReturnType } from './api.propTypes';
import { GenericStorageConstants } from 'shared/constants';

// const baseURL = Config.configs.apiBaseUrl;
export const useLoginMutation = (props: ApiProps<any>): ApiReturnType<LoginPayload> => {
	
	const [data, setData] = useState<any>(null);
	const [error, setError] = useState(null);
	const [isLoading, setIsLoading] = useState(false);
	const invokeAPI = (payload: LoginPayload): void => {
		setIsLoading(true);
		HttpClient
			.post(API.OAuth, { data: payload, apiBaseUrl: '/oauth/v2' })
			.then((res) => {
				setData(res.data);
			})
			.catch((error_) => {
				setError(error_.response.data);
			}).finally(() => {
				setIsLoading(false);
			});
	};

	return [invokeAPI, { isLoading, error, data }];
};

export const useValidateUserMutation = (props: ApiProps<LoginPayload>): ApiReturnType<LoginPayload> => {
	const [data, setData] = useState(null);
	const [error, setError] = useState(null);
	const [isLoading, setIsLoading] = useState(false);

	const invokeAPI = (payload: LoginPayload): void => {
		setIsLoading(true);
		HttpClient
			.post(API.ValidateUserName, { data: payload })
			.then((res) => {
				setData(res.data.data);
			})
			.catch((error_) => {
				setError(error_.response.data);
			}).finally(() => {
				setIsLoading(false);
			});
	};

	return [invokeAPI, { isLoading, error, data }];
};

export const useSignUpUserMutation = (props: ApiProps<AuthSignupAPIPayload>): ApiReturnType<AuthSignupAPIPayload> => {
	const [data, setData] = useState<any>(null);
	const [error, setError] = useState(null);
	const [loaded, setLoaded] = useState(false);
	const [, setUserData] = useLocalStorage(GenericStorageConstants.UserData, {});
	const [, setUserId] = useLocalStorage(GenericStorageConstants.UserId, '');

	const invokeAPI = (payload: AuthSignupAPIPayload): void => {
		setLoaded(true);
		HttpClient
			.post(API.Register, { data: payload })
			.then((res: { data: UserDetails }) => {
				// localStorage.setItem(GenericStorageConstants.UserData, Utils.toString(res.data));
				setUserData(res.data);
				setUserId(res.data.id as string);
				// localStorage.setItem(GenericStorageConstants.UserId, '' + res.data.id);
				setData(res.data);
			})
			.catch((error_) => {
				setError(error_.response.data);
			}).finally(() => {
				setLoaded(false);
			});
	};

	return [invokeAPI, { isLoading: loaded, error, data }];
};

export const useRegisterUserMutation = (props: ApiProps<{ data: RegisterUserPayload; userId: number | string }>): ApiReturnType<{ data: RegisterUserPayload; userId: string | number }> => {
	const [data, setData] = useState(null);
	const [error, setError] = useState(null);
	const [loaded, setLoaded] = useState(false);
	const [, setUserData] = useLocalStorage(GenericStorageConstants.UserData, {});

	const invokeAPI = (payload: { data: RegisterUserPayload; userId: string | number }): void => {
		setLoaded(true);
		HttpClient
			.patch(API.User, {
				data: payload.data,
				paramsData: [['[userId]', payload.userId]]
			})
			.then((res: any) => {
				setUserData(res.data.data);
				// localStorage.setItem(GenericStorageConstants.UserData, Utils.toString(res.data.data));
				setData(res.data.data);
			})
			.catch((error_) => {
				setError(error_.response.data);
			}).finally(() => {
				setLoaded(false);
			});
	};

	return [invokeAPI, { isLoading: loaded, error, data }];
};

export const useResetPasswordMutation = (props: ApiProps<ResetPasswordPayload>): ApiReturnType<ResetPasswordPayload> => {
	const [data, setData] = useState<any>(null);
	const [error, setError] = useState(null);
	const [loaded, setLoaded] = useState(false);

	const invokeAPI = (payload: ResetPasswordPayload): void => {
		setLoaded(true);
		HttpClient
			.post(API.ResetPassword, {
				data: payload
			})
			.then((res: any) => {
				setData(true);
			})
			.catch((error_) => {
				setError(error_.response.data);
			}).finally(() => {
				setLoaded(false);
			});
	};

	return [invokeAPI, { isLoading: loaded, error, data }];
};

export const useGetUserMutation = (props: ApiProps<any>): ApiReturnType<void> => {
	const [data, setData] = useState(null);
	const [error, setError] = useState(null);
	const [loaded, setLoaded] = useState(false);
	const [, setUserData] = useLocalStorage(GenericStorageConstants.UserData, {});
	const invokeAPI = (): void => {
		setLoaded(true);
		HttpClient
			.get(API.Me, {})
			.then((res: any) => {
				setUserData(res.data.data);
				// localStorage.setItem(GenericStorageConstants.UserData, Utils.toString(res.data));
				setData(res);
			})
			.catch((error_) => {
				setError(error_.response.data);
			}).finally(() => {
				setLoaded(false);
			});
	};

	return [invokeAPI, { isLoading: loaded, error, data }];
};

export const useGetTimezonesMutation = (props: ApiProps<any>): ApiReturnType<void> => {
	const [data, setData] = useState(null);
	const [error, setError] = useState(null);
	const [loaded, setLoaded] = useState(false);
	const invokeAPI = (): void => {
		setLoaded(true);
		HttpClient
			.get(API.Timezones, {})
			.then((res: any) => {
				setData(res.data);
			})
			.catch((error_) => {
				setError(error_.response.data);
			}).finally(() => {
				setLoaded(false);
			});
	};

	return [invokeAPI, { isLoading: loaded, error, data }];
};

export const useGetLanguagesMutation = (props: ApiProps<any>): ApiReturnType<void> => {
	const [data, setData] = useState(null);
	const [error, setError] = useState(null);
	const [loaded, setLoaded] = useState(false);
	const invokeAPI = (): void => {
		setLoaded(true);
		HttpClient
			.get(API.Languages, {})
			.then((res: any) => {
				setData(res.data);
			})
			.catch((error_) => {
				setError(error_.response.data);
			}).finally(() => {
				setLoaded(false);
			});
	};

	return [invokeAPI, { isLoading: loaded, error, data }];
};

export const useServeParticipantMutation = (props: ApiProps<ServeParticipantPayload>): ApiReturnType<ServeParticipantPayload> => {
	const [data, setData] = useState<any>(null);
	const [error, setError] = useState(null);
	const [loaded, setLoaded] = useState(false);

	const invokeAPI = (payload: ServeParticipantPayload): void => {
		setLoaded(true);
		HttpClient
			.post(API.ServeParticipant, {
				data: payload
			})
			.then((res: any) => {
				setData(res.data);
			})
			.catch((error_) => {
				setError(error_.response.data);
			}).finally(() => {
				setLoaded(false);
			});
	};

	return [invokeAPI, { isLoading: loaded, error, data }];
};

export const useContactPreferenceMutation = (props: ApiProps<{ data: ContactPreferencesPayload; userId: number | string }>): ApiReturnType<{ data: ContactPreferencesPayload; userId: string | number }> => {
	const [data, setData] = useState(null);
	const [error, setError] = useState(null);
	const [loaded, setLoaded] = useState(false);

	const invokeAPI = (payload: { data: ContactPreferencesPayload; userId: string | number }): void => {
		setLoaded(true);
		HttpClient
			.patch(API.User, {
				data: payload.data,
				paramsData: [['[userId]', payload.userId]]
			})
			.then((res: any) => {
				setData(res.data.data);
			})
			.catch((error_) => {
				setError(error_.response.data);
			}).finally(() => {
				setLoaded(false);
			});
	};

	return [invokeAPI, { isLoading: loaded, error, data }];
};