export type ApiReturnType<T> = [(val: T) => void, {isLoading: boolean; error:any, data: any}];
/* export interface ApiUrl {
	apiBaserUrl: string;
};
 */
export interface ApiProps<T> {
	responseType?: T
};

export interface APIset {
	url: string;
	method: string;
}
