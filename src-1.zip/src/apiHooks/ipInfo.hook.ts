import { useState } from "react";
import { useLocalStorage } from 'usehooks-ts';
import { HttpClient } from "../http";
import { ApiReturnType } from "./api.propTypes";
import { GenericStorageConstants } from 'shared/constants';

export const useGetIpInfoMutation = (): ApiReturnType<void> => {
	const [data, setData] = useState(null);
	const [error, setError] = useState(null);
	const [isLoading, setIsLoading] = useState(false);
	const [, setIpInfo] = useLocalStorage(GenericStorageConstants.IpInfo, {});

	const invokeAPI = (): void => {
		setIsLoading(true);
		HttpClient
			.get('', {
				baseURL: 'https://ipinfo.io',
				apiBaseUrl: null,
				headers: {
					'accept': 'application/json',
					'authorization': 'Bearer 7b51a6c7b82163',
					'cache-control': 'no-cache'
				}
			})
			.then((res) => {
				setIpInfo(res.data)
				// localStorage.setItem(GenericStorageConstants.niu_IpInfo, JSON.stringify(res.data));
				setData(res.data);
			})
			.catch((error_) => {
				console.log('@@@ INFO API ERROR', error_)
				setError(error_.response.data);
			}).finally(() => {
				setIsLoading(false);
			});
	};

	return [invokeAPI, { isLoading, error, data }];
};