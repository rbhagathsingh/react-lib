import React from 'react';
function ChangePassword(): JSX.Element {
	return (
		<div>Change password page</div>
	);
}

export default ChangePassword;