import React from 'react';
import { LognWrapperProps } from './loginWrapperPropTypes';

function LoginWrapper(props: LognWrapperProps): JSX.Element {
    return (
	<div className={'login-page' + (props.className ? ' ' + props.className : '')}>
		<div className="pp-logo-block text-center">
			<i className="icon-full-logo"></i>
		</div>
		{props.title && (<h1 className="pt-3 pb-4 text-center">{props.title}</h1>)}
		{props.subTitle && (<h3 className="text-center">{props.subTitle}</h3>)}
		{(props.children != null) && props.children}
	</div>
    );
}

export default LoginWrapper;