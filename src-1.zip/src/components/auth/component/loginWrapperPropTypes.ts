import { PropsWithChildren } from "react";

export interface LognWrapperProps extends PropsWithChildren {
	title?: string;
	subTitle?: string;
	className?: string;
}