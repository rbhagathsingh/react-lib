import React, { useState, useEffect, FunctionComponent } from 'react';
import LoginWrapper from '../component/loginWrapper';
import { useForm } from 'react-hook-form';
import { useNavigate } from 'react-router-dom';
import Preloader from '../../../shared/components/preloader/preloader.component';
import { AlertConfirm, FormField } from '../../../shared/components';
import { Utils } from 'shared/utils';
import { LoginUtil } from '../../../services';
import { useResetPasswordMutation } from '../../../apiHooks/api.hooks';
import { ForgotPasswordPageProps } from '../models/auth.models';

const ForgotPasswordPage: FunctionComponent<ForgotPasswordPageProps> = ({className}): JSX.Element => {
	const navigate = useNavigate();
	const [resetPasswordAPI, { isLoading, error, data }] = useResetPasswordMutation({});
	const { handleSubmit, control, formState: { errors } } = useForm({
		mode: 'onChange',
		defaultValues: {
			emailPhone: '',
		}
	});

	const [, setResetForm] = useState({
		emailPhone: '',
	});

	const [apiError, setApiError] = useState('');
	const [openAlert, setOpenAlert] = useState(false);
	const [formErrorMessages] = useState({
		required: 'Email or Phone is required.',
		validEmailPhone: 'Email or Phone is not correct'
	});

	const sendEmailForResetPassword = (obj: any): void => {
		resetPasswordAPI({
			username: obj.emailPhone,
			client_id: process.env.REACT_APP_CLIENT_ID || '',
			client_secret: process.env.REACT_APP_CLIENT_SECRET || '',
			resetLink: `${window.location.origin}/change-password`,
			usedHost: window.location.origin
		});
	};

	const onSubmit = (data: any): void => {
		setResetForm(data);
		sendEmailForResetPassword(data);
	};

	const changeInput = (evt: any): string => {
		let val = evt.target.value || '';
		const isPhoneEmail = LoginUtil.validateLogin(val);
		if (isPhoneEmail === 'phone') {
			val = LoginUtil.formatPhone(evt.target.value);
		}
		return val;
	};

	/**
	* @description - Validate Email/Phone format
	* @function validateEmailPhone
	* @param {string} value - Email/Phone text
	*/
	const validateEmailPhone = (value: any): boolean => {
		if (LoginUtil.validateLogin(value)) {
			return true;
		}
		return false;
	};

	/**
	* @description - Go to login page method
	* @function goToLogin
	*/
	const goToLogin = (): void => {
		navigate({
				pathname: '/login'
		});
	};

	/**
	* @description - Alert callback method
	* @function alertOk
	*/
	const alertOk = (): void => {
		setOpenAlert(false);
		Utils.timeout('reset', () => {
			navigate({
				pathname: '/login'
			});
		}, 300);
	};

	useEffect(() => {
		if (error) {
			setApiError(error.description);
		}
	}, [error]);

	useEffect(() => {
		if (data) {
			setOpenAlert(true);
		}
	}, [data]);

	useEffect(() => {
		document.body.classList.add('bg');
			return () => {
					 document.body.classList.remove('bg');  
			};
	}, []);

  return (
	<LoginWrapper subTitle="Can't remember your password?" className={'reset-password-block' + (className ? ' ' + className : '')}>
		<React.Fragment>
			<div className="text-center pt-3 pb-3">No problem! To reset your password, provide your email address or phone number below.</div>
			<form onSubmit={handleSubmit(onSubmit)}>
				<div className="login-form-bock">
					<FormField fieldName="emailPhone" label="Email address or phone number" placeholder="Email or Phone"
						control={ control }
						rules={{
							required: true, 
							validate: { validEmailPhone: validateEmailPhone }
							}}
							errors={ errors }
							errorMessages={ formErrorMessages }
							inputChange={(evt) => { 
								setApiError('');
								return changeInput(evt);
							 }}
						/>
					<div className="mb-14">
						<div className='text-center'><a onClick={goToLogin}>I remember now. SignIn again</a></div>
					</div>
					{apiError.length > 0 && (
						<div className="alert alert-danger alert-block">{apiError}</div>
					)}
					<div className="d-grid gap-2  pb-4 pt-3">
						<button className="btn btn-primary login-btn d-flex justify-content-center align-items-center" type="submit" disabled={isLoading}>
							<span>Continue</span>
							{ isLoading && (<Preloader/>)}
						</button>
					</div>
				</div>
			</form>
			<AlertConfirm 
					isOpen={openAlert}
					onBtnClick={alertOk}
					type="alert">
				<React.Fragment>
					Need to change your password? No problem. We just sent you an e-mail with instructions. Follow the directions there to change your password.
				</React.Fragment>
			</AlertConfirm>
		</React.Fragment>
	</LoginWrapper>
);
}

export default ForgotPasswordPage;