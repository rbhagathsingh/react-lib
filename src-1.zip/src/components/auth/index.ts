export { default as Password } from './password/password.page';
export { default as Login } from './login/login.page';
export { default as LoginWrapper } from './component/loginWrapper';
export { default as ChangePassword } from './changePassword/changePassword.page';
export { default as ForgotPassword } from './forgotPassword/forgotPassword.page';
export { default as Registration } from './registration/registration.page';