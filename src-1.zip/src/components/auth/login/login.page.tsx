/* eslint  @typescript-eslint/no-misused-promises: 0 */
/* eslint  @typescript-eslint/strict-boolean-expressions: 0 */
/* eslint  @typescript-eslint/prefer-nullish-coalescing: 0 */
/* eslint  @typescript-eslint/no-unused-vars: 0 */
import React, { useEffect, useState, FunctionComponent } from 'react';
import { useLocalStorage } from 'usehooks-ts';
import { useNavigate } from 'react-router-dom';
import _ from 'lodash';
import { Utils } from 'shared/utils';
// import { useLocalStorage } from '../../../shared/hooks';
import LoginWrapper from '../component/loginWrapper';
import { useForm } from 'react-hook-form';
import { Preloader, FormField } from '../../../shared/components';
// import { useGetIpInfoMutation } from '../../../store/api/ipInfo.api';
import { LoginUtil } from '../../../services';
import { GenericStorageConstants } from 'shared/constants';
import { useLoginMutation, useValidateUserMutation } from '../../../apiHooks/api.hooks';
import { LoginFormFields, LoginPageProps } from '../models/auth.models';
import { useGetIpInfoMutation } from '../../../apiHooks/ipInfo.hook';

/**
 * @file Login Page
 * @description Login page UI
 * @class
 */
const Login: FunctionComponent<LoginPageProps> = ({ apiCallback, className }): JSX.Element => {
	const navigate = useNavigate();
	const [ , setEmail ] = useLocalStorage(GenericStorageConstants.LoginEmail, '');
	const [loginAPI, { isLoading, error: loginApiError }] = useLoginMutation({});
	const [validateUserAPI, { isLoading: validateUserLoading, data: validatedUserData }] = useValidateUserMutation({});
	const [apiSecurityError, setApiSecurityError] = useState<boolean>(false);
	const [apiError, setApiError] = useState('');
	const [, setUserExist] = useState<boolean | null>(null);
	const [getIpInfo] = useGetIpInfoMutation();

	const { handleSubmit, control, formState: { errors } } = useForm({
		mode: 'onChange',
		defaultValues: {
			email: '',
		}
	});

	const [loginForm, setLoginForm] = useState<LoginFormFields>({
		email: '',
	});

	const [formErrorMessages] = useState({
		required: 'Email or Phone is required.',
		validEmailPhone: 'Email or Phone is not correct'
	});

	/**
	* @description - Login submit
	* @function onSubmit
	* @param {Object} data - Form Fields
	* @property {Object} data.email - Email field.
	*/
	const onSubmit = (data: LoginFormFields): void => {
		setLoginForm(data);
		loginAPI({
			client_id: process.env.REACT_APP_CLIENT_ID || '',
			client_secret: process.env.REACT_APP_CLIENT_SECRET || '',
			grant_type: process.env.REACT_APP_GRANT_TYPE || '',
			username: data.email || '',
			password: 'dummy password just to check if user exists'
		});
	};

	/**
	* @description - Google login method
	* @function googleLoginFunction
	*/
	const googleLoginFunction = (): boolean => {
		const marginLeft = (screen.availWidth - 800) / 2;
		const marginTop = (screen.availHeight - 600) / 2;
		const requestAttrs: any = {
			usedHost: process.env.REACT_APP_GOOGLE_USED_HOST || '',
			client_id: process.env.REACT_APP_GOOGLE_CLIENT_ID || '',
			client_secret: process.env.REACT_APP_GOOGLE_CLIENT_SECRET || '',
		};

		// dirty hack to send post request to modal window

		const form = document.createElement('form');
		form.setAttribute('method', 'POST');
		form.setAttribute('action', (process.env.REACT_APP_API_DOMAIN || '') + '/social/google');
		form.setAttribute('target', 'formresult');
		form.setAttribute('style', 'display: none;');
		for (const key in requestAttrs) {
			const hiddenField = document.createElement('input');
			hiddenField.setAttribute('name', key);
			hiddenField.setAttribute('value', requestAttrs[key]);
			form.append(hiddenField);
		}

		document.body.append(form);

		const loginWindow = window.open('', 'formresult', `top=${marginTop}, left=${marginLeft}, width=800, height=600`);
		form.submit();
		form.remove();
		function processMessage(event: any): void {
			const parsedData: any = JSON.parse(event.data);
			if ((loginWindow != null) && parsedData.access_token) {
				loginWindow.close();
				const win: any = window;
				win.socialAuthResponse = parsedData;
				// StorageService.setItem('fedral',true);
				// if(props.socialLoginSubmit) {
				//     props.socialLoginSubmit(window['socialAuthResponse']);
				// }
			} else if (loginWindow != null) {
				loginWindow.close();
			}
		}

		window.addEventListener('message', processMessage);

		return false;
	};

	/**
	* @description - Input text chagne event
	* @function changeInput
	*/
	const changeInput = (evt: any): string => {
		let val = evt.target.value || '';
		const isPhoneEmail = LoginUtil.validateLogin(val);
		if (isPhoneEmail === 'phone') {
			val = LoginUtil.formatPhone(evt.target.value);
		}
		return val;
	};

	/**
	* @description - Reset password page navigation method
	* @function onResetPassword
	*/
	const onResetPassword = (): void => {
		Utils.timeout('toLogin1', () => {
			navigate({
				pathname: '/reset-password'
			});
		}, 300);
	};

	/**
	* @description - Get API error messages
	* @function getErrorMessage
	* @param {string} res - API Error Object
	*/
	const getErrorMessage = (res: any): string => {
		let message = res;
		if (res.data) {
			res.data = typeof res.data === 'string' ? JSON.parse(res.data) : res.data;
			if (res.data.description) {
				return res.data.description;
			}
			if (res.data.error_description) {
				return res.data.error_description;
			}
			if (res.data.errors) {
				if (res.data.errors.title) {
					return res.data.errors.title[0];
				}
				return _.values(res.data.errors).flat().join('\n');
			}
			message = res.data.error ? res.data.error.message : res.data;
		} else {
			if (res.description) {
				message = res.description;
			} else if (res?.config?.url) {
				const configUrl: string = res.config.url;
				const location: string = window.location.href;
				message = `Error requesting ${configUrl} on page ${location}`;
			} else {
				message = Utils.toJson(res);
			}
		}
		return message;
	};

	/**
	* @description - Set API error messages in 
	* @function onResetPassword
	*/
	const setErrorMessage = (res: any): void => {
		const message = getErrorMessage(res);
		setApiError(message);
	};

	/**
	* @description - Invoke Validate User API
	* @function validateUser
	*/
	const validateUser = (): void => {
		validateUserAPI({
			client_id: process.env.REACT_APP_CLIENT_ID || '',
			client_secret: process.env.REACT_APP_CLIENT_SECRET || '',
			grant_type: process.env.REACT_APP_GRANT_TYPE || '',
			username: loginForm.email || '',
			password: 'dummy password just to check if user exists'
		});
	};

	/**
	* @description - Validate Email/Phone format
	* @function validateEmailPhone
	* @param {string} value - Email/Phone text
	*/
	const validateEmailPhone = (value: any): boolean => {
		if (LoginUtil.validateLogin(value)) {
			return true;
		}
		return false;
	};

	/**
	* @description - Login API error watcher
	* @function useEffect
	* @param {Requester~requestCallback} - use effect callback
	*/
	useEffect(() => {
		console.log(loginApiError);
		if (loginApiError) {
			if (loginApiError.code === 422 && loginApiError.description === 'Invalid password!') {
				// setStore(loginForm.email);
				setEmail(loginForm.email || '');
				validateUser();
			} else if (loginApiError.code === 403) {
				setApiSecurityError(true);
			} else if (loginApiError.code === 404 && loginApiError.description === 'User not found!') {
				// setStore(loginForm.email);
				setEmail(loginForm.email || '');
				navigate({
					pathname: '/create-password'
				});
			} else {
				setErrorMessage(loginApiError);
			}
		} else {
			setApiError('');
		}
	}, [loginApiError]);

	useEffect(() => {
		if (validatedUserData) {
			if (apiCallback) {
				apiCallback({
					type: 'validate-user',
					data: validatedUserData
				});
			}

			if (validatedUserData.isUserExists && !validatedUserData.isPasswordSet) {
				setUserExist(false);
			}
			if (validatedUserData.isUserExists && validatedUserData.isPasswordSet) {

				setUserExist(true);
				navigate({
					pathname: '/password'
				});
			}
		}
	}, [validatedUserData]);

	useEffect(() => {
		getIpInfo();
		document.body.classList.add('bg');
		return () => {
			document.body.classList.remove('bg');
		};
	}, []);

	return (
		<LoginWrapper title="Hello!" className={className ? className : ''}>
			<React.Fragment>
				<div className="social-auth-block">
					<button onClick={googleLoginFunction}>
						<span><img src={process.env.PUBLIC_URL + '/assets/images/google.png'} /></span>
						<span>Continue with Google</span>
					</button>
				</div>
				<div className="divider-block">
					<div>Or continue with e-mail address or SMS enabled phone number</div>
				</div>

				<form onSubmit={handleSubmit(onSubmit)}>
					<div className="login-form-bock pb-30">
						<FormField fieldName="email" label="Your E-mail address or phone number"
							control={control}
							rules={{
								required: true,
								validate: { validEmailPhone: validateEmailPhone }
							}}
							errors={errors}
							errorMessages={formErrorMessages}
							inputChange={(evt) => {
								setApiError('');
								return changeInput(evt);
							}}
						/>

						{apiError && (
							<div className="mb-14" >
								<div dangerouslySetInnerHTML={{ __html: apiError }}></div>
							</div>
						)}
						{apiSecurityError && (
							<div className="mb-14">
								<div className='alert alert-danger alert-block'> At ProofPIlot we take security very seriously.  For various reasons, your account has been locked.  If you did not receive an e-mail or SMS to reset your account, <a onClick={onResetPassword}>please click here to manually initiate a reset.</a>
								</div>
							</div>
						)}
						<div className="d-grid gap-2">
							<button className="btn btn-primary login-btn d-flex justify-content-center align-items-center" type="submit" disabled={(isLoading || validateUserLoading)}>
								<span>Login</span>
								{(isLoading || validateUserLoading) && (<Preloader />)}

							</button>
						</div>
					</div>

					<div className="text-block">
						<div>New users can finish creating account on the following screens. </div>
						<div>ProofPilot takes your security and privacy seriously. We collect contact information to secure access to the sensitive information you share</div>
					</div>
				</form>
			</React.Fragment>
		</LoginWrapper>
	);
}

export default Login;