export interface AuthSignupAPIPayload {
	registration: {
		username: string;
    plainPassword: string;
    fullname: string;
	},
	client_id: string;
  client_secret: string;
  usedHost: string;
};

export interface OAuthAPIPayload {
	username: string;
  password: string;
  remember_me?: number | boolean;
  client_id: string;
  client_secret: string;
  grant_type: string;
}

export interface OAuthAPIResponse {
	access_token: string;
  expires_in: number
  token_type: string;
  scope: any
}

export interface RegisterUserPayload {
  pii: {
    gender: string;
    birthDate: string;
    addresses: {
			zipCode: string | number;
			country: string;
			state: string;
		}[],
    firstName: string;
    lastName: string;
  },
  timezone: string;
  language: string;
};

export interface RegisterUserFormFields {
		firstName: string;
		lastName: string;
		month: string;
		date: string;
		year: string;
		gender: string;
		country: string;
		state: string;
		timezone: string;
		userLang: string;
};


export interface ResetPasswordPayload {
	username: string;
  resetLink: string;
  client_id: string;
  client_secret: string;
  usedHost: string;
}



export interface LoginPayload {
	client_id: string;
	client_secret: string;
	grant_type: string;
	username: string;
	password: string;
	remember_me?: string;
}

export interface LoginFormFields {
	email?: string;
	password?: string;
	rememberMe?: string;
}

export interface AuthPageProps {
  apiCallback?: (res: {type: 'valid-user' | 'validate-user' | 'signup' | 'registration' | 'login', data: any}) => void;
	className?: string;
}

export interface LoginPageProps extends AuthPageProps {
	title?: string;
}

export interface PasswordPageProps extends AuthPageProps {
	title?: string;
}

export interface RegistrationPageProps extends AuthPageProps {
	title?: string;
}

export interface ForgotPasswordPageProps extends AuthPageProps {
	title?: string;
}