import React, { FunctionComponent, useEffect, useState } from 'react';
import { useLocalStorage } from 'usehooks-ts';
import { useLocation, useNavigate } from 'react-router-dom';
// import { useLoginMutation, useSignUpUserMutation } from '../../../store/api/auth.api';
// import { useLocalStorage } from '../../../shared/hooks';
import { GenericStorageConstants } from 'shared/constants';
import LoginWrapper from '../component/loginWrapper';
import { useForm, Controller } from 'react-hook-form';
import { Preloader, FormField } from '../../../shared/components';
import { Utils } from 'shared/utils';
import { RegExp } from '../../../shared/constants/regex.constants';
import { useGetUserMutation, useLoginMutation, useSignUpUserMutation } from '../../../apiHooks/api.hooks';
import { PasswordPageProps } from '../models/auth.models';
/* eslint  @typescript-eslint/no-misused-promises: 0 */ 
/* eslint  @typescript-eslint/strict-boolean-expressions: 0 */
/* eslint  @typescript-eslint/prefer-nullish-coalescing: 0 */

const PasswordPage: FunctionComponent<PasswordPageProps> = ({apiCallback, className}): JSX.Element  => {
	const navigate = useNavigate();
	const location = useLocation();
	const [ userName, setUserName ] = useLocalStorage(GenericStorageConstants.LoginEmail, '');
	const [, setToken ] = useLocalStorage(GenericStorageConstants.Token, {token: '', expiresIn: ''});
	const [loginAPI, { isLoading, data: loginData, error: loginApiError }] = useLoginMutation({});
	const [invokeMeAPI, { data: loggedInUserData }] = useGetUserMutation({});
	const [userSignUpAPI, { isLoading: isRegisterLoading, error: signUpError, data: userData }] = useSignUpUserMutation({});
	// const { loginData, loginApiError, apiFailCount, userData } = useSelector((state: RootState) => state.auth);
	
	const { handleSubmit, control, formState: { errors } } = useForm({
			mode: 'onChange',
			defaultValues: {
					password: '',
					confirmPassword: '',
					rememberMe: true
			}
	});

	const [loginForm, setLoginForm] = useState({
			password: '',
			confirmPassword: '',
			rememberMe: true
	});

	const [formErrorMessages] = useState({
		password: {
			required: 'Password is required.',
			pattern: 'Minimum 8 characters with 1 letter & 1 number.'
		},
		confirmPassword: {
			required: 'Confirm Password is required.',
			validConfirmPassword: 'Confirm Password is not matched'
		}
	});

	const [passwordStates, sePasswordStates] = useState({
			title: 'Welcome Back!',
			isPassword: true,
	});

	const [apiErrors, setApiErrors] = useState<string[]>([]);

	const [passwordApiError, setPasswordApiError] = useState('');
	const [apiSecurityError, setApiSecurityError] = useState<boolean>(false);
	const changeInput = (evt: any, key: string): string | boolean => {
			setPasswordApiError('');
			return key === 'rememberMe' ? evt.target.checked : evt.target.value;
	};

	const invokeLoginAPI = (data: any): void => {
			loginAPI({
					client_id: process.env.REACT_APP_CLIENT_ID || '',
					client_secret: process.env.REACT_APP_CLIENT_SECRET || '',
					grant_type: process.env.REACT_APP_GRANT_TYPE || '',
					username: userName,
					password: data.password,
					remember_me: data.rememberMe
			});
	};


	const onSubmit = (data: any): void => {
			setLoginForm(data);
			if (passwordStates.isPassword) {
					invokeLoginAPI(data);
			} else {
					userSignUpAPI({
							registration: {
									username: userName,
									plainPassword: data.password,
									fullname: data.password,
							},
							client_id: process.env.REACT_APP_CLIENT_ID || '',
							client_secret: process.env.REACT_APP_CLIENT_SECRET || '',
							usedHost: `${window.location.protocol}//${window.location.host.split(':')[0]}`
					});
			}
	};

	/**
* @description - Validate Email/Phone format
* @function validateEmailPhone
* @param {string} value - Email/Phone text
*/
const validConfirmPassword = (value: any): boolean => {
			const formField = control._formValues;
			return formField.password === value;
	};

/**
* @description - Go to login page method
* @function goToLogin
*/
	const goToLogin = (): void => {
			// clearStore();
			setUserName('');
			if (apiCallback) {
				apiCallback({
					type: 'login',
					data: null
				});
			}
			Utils.timeout('toLogin', () => {
					navigate({
							pathname: '/login'
					});
			}, 300);
	};

/**
* @description - Go to Reset page method
* @function goToResetPassword
*/
const goToResetPassword = (): void => {
	Utils.timeout('toLogin', () => {
			navigate({
					pathname: '/reset-password'
			});
	}, 300);
};
useEffect(() => {
	if (loggedInUserData) {
		navigate({
			pathname: '/'
		});
	}
}, [loggedInUserData]);

	useEffect(() => {
		 if (loginData) {
					/* setStore({
							token: loginData.access_token,
							expiresIn: loginData.expires_in
					}); */

					setToken({
						token: loginData.access_token,
						expiresIn: loginData.expires_in
					});

					// clearStore();
					setUserName('');

					if (apiCallback) {
						apiCallback({
							type: 'login',
							data: loginData
						});
					}

					if (passwordStates.isPassword) {
						invokeMeAPI();
						navigate({
							pathname: '/'
						});
					} else {
						navigate({
							pathname: '/registration'
						});
					}
		 }
	}, [loginData, passwordStates]);

	useEffect(() => {
		 if (userData) {
				 invokeLoginAPI(loginForm);
		 }
	}, [userData, loginForm]);

	useEffect(() => {
		 if (signUpError) {
			const arr: string[] = [];
			if (Utils.isObject(signUpError)) {
				Utils.eachKeyValue(signUpError, (value) => {
					arr.push(value || '');
				});
			}
			setApiErrors(arr);
		 }
	}, [signUpError]);

	useEffect(() => {
		 if (loginApiError) {
					if (loginApiError.code === 422 && loginApiError.description === 'Invalid password!') {
							setPasswordApiError('Wrong password');
					}
					if (loginApiError.code === 403) {
							setApiSecurityError(true);
					}
		 }
	}, [loginApiError]);

	useEffect(() => {
			sePasswordStates((prev: any) => {
					const obj = { ...prev };
					console.log(location.pathname, location.pathname.includes('/password'));
					obj.title = location.pathname.includes('/password') ? 'Welcome Back!' : 'Welcome to ProofPilot';
					obj.isPassword = location.pathname.includes('/password');
					return obj;
			});
		 
			document.body.classList.add('bg');
			return () => {
					 document.body.classList.remove('bg');  
			};
	}, []);

	return (
<LoginWrapper className={className ? className : ''} title={passwordStates.isPassword ? passwordStates.title : ''} subTitle={passwordStates.isPassword ? '' : passwordStates.title
	}>
	<React.Fragment>
		<form onSubmit={handleSubmit(onSubmit)}>
			{!passwordStates.isPassword && (
			<React.Fragment>
				<div className="text-center">{userName}</div>
				<h5 className="text-center pt-3 pb-3">LET&apos;S FINISH CREATING YOUR ACCOUNT.</h5>
			</React.Fragment>
							)}
			{passwordStates.isPassword && (
			<h6 className="text-center">Please provide your password to continue</h6>
							)}
			
			<div className="login-form-bock pb-10">
				<FormField fieldName="password" label="Please type your password" inputType="password"
					control={ control }
					rules={{
						required: true, 
						pattern: RegExp.Password
						}}
						errors={ errors }
						errorMessages={ formErrorMessages.password }
						inputChange={(evt) => { 
							return changeInput(evt, 'password');
						}}
						customChildren={() => {
							return passwordApiError && (<div className="form-field-error">{passwordApiError}</div>);
						}}
						customValidate={passwordApiError !== ''}
					/>

				{!passwordStates.isPassword && (
					<FormField fieldName="confirmPassword" label="Please re-type your password" inputType="password"
					control={ control }
					rules={{ 
						required: !passwordStates.isPassword,
						validate: {
								validConfirmPassword: validConfirmPassword
						}
						}}
						errors={ errors }
						errorMessages={ formErrorMessages.confirmPassword }
						inputChange={(evt) => { 
							return changeInput(evt, 'confirmPassword');
						}}
						customChildren={() => {
							return passwordApiError && (<div className="form-field-error">{passwordApiError}</div>);
						}}
						customValidate={passwordApiError !== ''}
					/>
				)}

				{apiSecurityError && (
				<div className="mb-14">
					<div className='alert alert-danger alert-block'> At ProofPIlot we take security very seriously.  For various reasons, your account has been locked.  If you did not receive an e-mail or SMS to reset your account, <a onClick={goToResetPassword}>please click here to manually initiate a reset.</a>
					</div>
				</div>
											)}
				{apiErrors.length > 0 && (
					<div className="mb-14">
						{apiErrors.map((ele) => {
							return <div key={ele} className='alert alert-danger alert-block'>{ele}</div>;
						})}
					</div>
				)}
									 
				{passwordStates.isPassword && (
				<div className="mb-14">
					<div className='text-center'><a onClick={goToResetPassword}>Forgot Password</a></div>
				</div>
									)}
				{!passwordStates.isPassword && (
					<React.Fragment>
						<div className="mb-14">
							<div className='text-center'>Think you already may have an account?</div>
						</div>
						<div className="mb-14">
							<div className='text-center'><a onClick={goToLogin}>Try a different sign-in method</a></div>
						</div>
					</React.Fragment>
					
				)}
				<div className="mb-6 form-check">
					<Controller
															name="rememberMe"
															control={ control }
															render={({ field: { onChange, value } }) => {
																	return <React.Fragment>
																		<input className="form-check-input" id="remember" type="checkbox" checked={value} onChange={ onChange } /> 
<label className="form-check-label" htmlFor="remember">Keep me logged in for 30 days</label>
																	</React.Fragment>;
															}}
													/>
				</div>
											
			</div>
			<div className="text-block no-padding mb-8"> Use this feature in combination with your device security features to make it easier to log in and use ProofPilot. If you share your device with others or do not use device security features, do not use this feature to maintain your security
			</div>
			<div className="d-grid gap-2  pb-16 pt-3">
				<button className="btn btn-primary login-btn d-flex justify-content-center align-items-center" disabled={isLoading || isRegisterLoading} type="submit">
					<span>Continue</span>
					{(isLoading || isRegisterLoading) && (<Preloader/>)}
				</button>
			</div>
			{!passwordStates.isPassword && (
			<div className="text-block pt-0">
				By continuing, you agree to periodic communications and reminders from ProofPilot. Any data you share with ProofPilot is secured and encrypted and will only be provided to studies with your expressed permission. Before you join each study, we’ll tell you all you need to know about the risks and rights you have. We use cookies to improve your user experience.
			</div>
							)}
		</form>
	</React.Fragment>
</LoginWrapper>
	);
}


export default PasswordPage;