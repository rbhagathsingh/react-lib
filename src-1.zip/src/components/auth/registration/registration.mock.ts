/* eslint quote-props: 0 */
/* eslint unicorn/escape-case: 0 */

export const GenderData = [
	{ name: 'Female', value: 'female' },
	{ name: 'Male', value: 'male' },
	{ name: 'Transgender', value: 'transgender' },
	{ name: 'Gender Non Conforming', value: 'non_conforming' },
];
export const MonthNames = [
	'Jan',
	'Feb',
	'Mar',
	'Apr',
	'May',
	'Jun',
	'Jul',
	'Aug',
	'Sep',
	'Oct',
	'Nov',
	'Dec'
];

export const CountriesData = [
	{
			'code': 'AF',
			'name': 'Afghanistan'
	},
	{
			'code': 'AL',
			'name': 'Albania'
	},
	{
			'code': 'DZ',
			'name': 'Algeria'
	},
	{
			'code': 'AD',
			'name': 'Andorra'
	},
	{
			'code': 'AO',
			'name': 'Angola'
	},
	{
			'code': 'AG',
			'name': 'Antigua and Barbuda'
	},
	{
			'code': 'AR',
			'name': 'Argentina'
	},
	{
			'code': 'AM',
			'name': 'Armenia'
	},
	{
			'code': 'AU',
			'name': 'Australia'
	},
	{
			'code': 'AT',
			'name': 'Austria'
	},
	{
			'code': 'AZ',
			'name': 'Azerbaijan'
	},
	{
			'code': 'BH',
			'name': 'Bahrain'
	},
	{
			'code': 'BD',
			'name': 'Bangladesh'
	},
	{
			'code': 'BB',
			'name': 'Barbados'
	},
	{
			'code': 'BY',
			'name': 'Belarus'
	},
	{
			'code': 'BE',
			'name': 'Belgium'
	},
	{
			'code': 'BZ',
			'name': 'Belize'
	},
	{
			'code': 'BJ',
			'name': 'Benin'
	},
	{
			'code': 'BT',
			'name': 'Bhutan'
	},
	{
			'code': 'BO',
			'name': 'Bolivia'
	},
	{
			'code': 'BA',
			'name': 'Bosnia and Herzegovina'
	},
	{
			'code': 'BW',
			'name': 'Botswana'
	},
	{
			'code': 'BR',
			'name': 'Brazil'
	},
	{
			'code': 'BN',
			'name': 'Brunei'
	},
	{
			'code': 'BG',
			'name': 'Bulgaria'
	},
	{
			'code': 'BF',
			'name': 'Burkina Faso'
	},
	{
			'code': 'BI',
			'name': 'Burundi'
	},
	{
			'code': 'KH',
			'name': 'Cambodia'
	},
	{
			'code': 'CM',
			'name': 'Cameroon'
	},
	{
			'code': 'CA',
			'name': 'Canada'
	},
	{
			'code': 'CV',
			'name': 'Cape Verde'
	},
	{
			'code': 'CF',
			'name': 'Central African Republic'
	},
	{
			'code': 'TD',
			'name': 'Chad'
	},
	{
			'code': 'CL',
			'name': 'Chile'
	},
	{
			'code': 'CO',
			'name': 'Colombia'
	},
	{
			'code': 'KM',
			'name': 'Comoros'
	},
	{
			'code': 'CR',
			'name': 'Costa Rica'
	},
	{
			'code': 'CI',
			'name': 'C\u00f4te d\'Ivoire'
	},
	{
			'code': 'HR',
			'name': 'Croatia'
	},
	{
			'code': 'CU',
			'name': 'Cuba'
	},
	{
			'code': 'CY',
			'name': 'Cyprus'
	},
	{
			'code': 'CZ',
			'name': 'Czech Republic'
	},
	{
			'code': 'CD',
			'name': 'Democratic Republic of the Congo'
	},
	{
			'code': 'DK',
			'name': 'Denmark'
	},
	{
			'code': 'DJ',
			'name': 'Djibouti'
	},
	{
			'code': 'DM',
			'name': 'Dominica'
	},
	{
			'code': 'DO',
			'name': 'Dominican Republic'
	},
	{
			'code': 'TL',
			'name': 'East Timor'
	},
	{
			'code': 'EC',
			'name': 'Ecuador'
	},
	{
			'code': 'EG',
			'name': 'Egypt'
	},
	{
			'code': 'SV',
			'name': 'El Salvador'
	},
	{
			'code': 'GQ',
			'name': 'Equatorial Guinea'
	},
	{
			'code': 'ER',
			'name': 'Eritrea'
	},
	{
			'code': 'EE',
			'name': 'Estonia'
	},
	{
			'code': 'ET',
			'name': 'Ethiopia'
	},
	{
			'code': 'FM',
			'name': 'Federated States of Micronesia'
	},
	{
			'code': 'FJ',
			'name': 'Fiji'
	},
	{
			'code': 'FI',
			'name': 'Finland'
	},
	{
			'code': 'FR',
			'name': 'France'
	},
	{
			'code': 'GA',
			'name': 'Gabon'
	},
	{
			'code': 'GM',
			'name': 'Gambia'
	},
	{
			'code': 'GE',
			'name': 'Georgia'
	},
	{
			'code': 'DE',
			'name': 'Germany'
	},
	{
			'code': 'GH',
			'name': 'Ghana'
	},
	{
			'code': 'GR',
			'name': 'Greece'
	},
	{
			'code': 'GD',
			'name': 'Grenada'
	},
	{
			'code': 'GT',
			'name': 'Guatemala'
	},
	{
			'code': 'GN',
			'name': 'Guinea'
	},
	{
			'code': 'GW',
			'name': 'Guinea-Bissau'
	},
	{
			'code': 'GY',
			'name': 'Guyana'
	},
	{
			'code': 'HT',
			'name': 'Haiti'
	},
	{
			'code': 'HN',
			'name': 'Honduras'
	},
	{
			'code': 'HU',
			'name': 'Hungary'
	},
	{
			'code': 'IS',
			'name': 'Iceland'
	},
	{
			'code': 'IN',
			'name': 'India'
	},
	{
			'code': 'ID',
			'name': 'Indonesia'
	},
	{
			'code': 'IR',
			'name': 'Iran'
	},
	{
			'code': 'IQ',
			'name': 'Iraq'
	},
	{
			'code': 'IE',
			'name': 'Ireland'
	},
	{
			'code': 'IL',
			'name': 'Israel'
	},
	{
			'code': 'IT',
			'name': 'Italy'
	},
	{
			'code': 'JM',
			'name': 'Jamaica'
	},
	{
			'code': 'JP',
			'name': 'Japan'
	},
	{
			'code': 'JO',
			'name': 'Jordan'
	},
	{
			'code': 'KZ',
			'name': 'Kazakhstan'
	},
	{
			'code': 'KE',
			'name': 'Kenya'
	},
	{
			'code': 'NL',
			'name': 'Kingdom of the Netherlands'
	},
	{
			'code': 'KI',
			'name': 'Kiribati'
	},
	{
			'code': 'XK',
			'name': 'Kosovo'
	},
	{
			'code': 'KW',
			'name': 'Kuwait'
	},
	{
			'code': 'KG',
			'name': 'Kyrgyzstan'
	},
	{
			'code': 'LA',
			'name': 'Laos'
	},
	{
			'code': 'LV',
			'name': 'Latvia'
	},
	{
			'code': 'LB',
			'name': 'Lebanon'
	},
	{
			'code': 'LS',
			'name': 'Lesotho'
	},
	{
			'code': 'LR',
			'name': 'Liberia'
	},
	{
			'code': 'LY',
			'name': 'Libya'
	},
	{
			'code': 'LI',
			'name': 'Liechtenstein'
	},
	{
			'code': 'LT',
			'name': 'Lithuania'
	},
	{
			'code': 'LU',
			'name': 'Luxembourg'
	},
	{
			'code': 'MG',
			'name': 'Madagascar'
	},
	{
			'code': 'MW',
			'name': 'Malawi'
	},
	{
			'code': 'MY',
			'name': 'Malaysia'
	},
	{
			'code': 'MV',
			'name': 'Maldives'
	},
	{
			'code': 'ML',
			'name': 'Mali'
	},
	{
			'code': 'MT',
			'name': 'Malta'
	},
	{
			'code': 'MH',
			'name': 'Marshall Islands'
	},
	{
			'code': 'MR',
			'name': 'Mauritania'
	},
	{
			'code': 'MU',
			'name': 'Mauritius'
	},
	{
			'code': 'MX',
			'name': 'Mexico'
	},
	{
			'code': 'MD',
			'name': 'Moldova'
	},
	{
			'code': 'MC',
			'name': 'Monaco'
	},
	{
			'code': 'MN',
			'name': 'Mongolia'
	},
	{
			'code': 'ME',
			'name': 'Montenegro'
	},
	{
			'code': 'MA',
			'name': 'Morocco'
	},
	{
			'code': 'MZ',
			'name': 'Mozambique'
	},
	{
			'code': 'MM',
			'name': 'Myanmar'
	},
	{
			'code': 'NA',
			'name': 'Namibia'
	},
	{
			'code': 'NR',
			'name': 'Nauru'
	},
	{
			'code': 'NP',
			'name': 'Nepal'
	},
	{
			'code': 'NL',
			'name': 'Netherlands'
	},
	{
			'code': 'NZ',
			'name': 'New Zealand'
	},
	{
			'code': 'NI',
			'name': 'Nicaragua'
	},
	{
			'code': 'NE',
			'name': 'Niger'
	},
	{
			'code': 'NG',
			'name': 'Nigeria'
	},
	{
			'code': 'KP',
			'name': 'North Korea'
	},
	{
			'code': 'NO',
			'name': 'Norway'
	},
	{
			'code': 'OM',
			'name': 'Oman'
	},
	{
			'code': 'PK',
			'name': 'Pakistan'
	},
	{
			'code': 'PW',
			'name': 'Palau'
	},
	{
			'code': 'PA',
			'name': 'Panama'
	},
	{
			'code': 'PG',
			'name': 'Papua New Guinea'
	},
	{
			'code': 'PY',
			'name': 'Paraguay'
	},
	{
			'code': 'CN',
			'name': 'People\'s Republic of China'
	},
	{
			'code': 'PE',
			'name': 'Peru'
	},
	{
			'code': 'PH',
			'name': 'Philippines'
	},
	{
			'code': 'PL',
			'name': 'Poland'
	},
	{
			'code': 'PT',
			'name': 'Portugal'
	},
	{
			'code': 'QA',
			'name': 'Qatar'
	},
	{
			'code': 'MK',
			'name': 'Republic of Macedonia'
	},
	{
			'code': 'CG',
			'name': 'Republic of the Congo'
	},
	{
			'code': 'RO',
			'name': 'Romania'
	},
	{
			'code': 'RU',
			'name': 'Russia'
	},
	{
			'code': 'RW',
			'name': 'Rwanda'
	},
	{
			'code': 'KN',
			'name': 'Saint Kitts and Nevis'
	},
	{
			'code': 'LC',
			'name': 'Saint Lucia'
	},
	{
			'code': 'VC',
			'name': 'Saint Vincent and the Grenadines'
	},
	{
			'code': 'WS',
			'name': 'Samoa'
	},
	{
			'code': 'SM',
			'name': 'San Marino'
	},
	{
			'code': 'ST',
			'name': 'Sao Tom\u00e9 and Pr\u00edncipe'
	},
	{
			'code': 'SN',
			'name': 'Senegal'
	},
	{
			'code': 'RS',
			'name': 'Serbia'
	},
	{
			'code': 'SC',
			'name': 'Seychelles'
	},
	{
			'code': 'SL',
			'name': 'Sierra Leone'
	},
	{
			'code': 'SG',
			'name': 'Singapore'
	},
	{
			'code': 'SK',
			'name': 'Slovakia'
	},
	{
			'code': 'SI',
			'name': 'Slovenia'
	},
	{
			'code': 'SO',
			'name': 'Somalia'
	},
	{
			'code': 'ZA',
			'name': 'South Africa'
	},
	{
			'code': 'KR',
			'name': 'South Korea'
	},
	{
			'code': 'SS',
			'name': 'South Sudan'
	},
	{
			'code': 'ES',
			'name': 'Spain'
	},
	{
			'code': 'LK',
			'name': 'Sri Lanka'
	},
	{
			'code': 'SD',
			'name': 'Sudan'
	},
	{
			'code': 'SR',
			'name': 'Suriname'
	},
	{
			'code': 'SZ',
			'name': 'Swaziland'
	},
	{
			'code': 'SE',
			'name': 'Sweden'
	},
	{
			'code': 'CH',
			'name': 'Switzerland'
	},
	{
			'code': 'SY',
			'name': 'Syria'
	},
	{
			'code': 'TW',
			'name': 'Taiwan'
	},
	{
			'code': 'TJ',
			'name': 'Tajikistan'
	},
	{
			'code': 'TZ',
			'name': 'Tanzania'
	},
	{
			'code': 'TH',
			'name': 'Thailand'
	},
	{
			'code': 'BS',
			'name': 'The Bahamas'
	},
	{
			'code': 'TG',
			'name': 'Togo'
	},
	{
			'code': 'TO',
			'name': 'Tonga'
	},
	{
			'code': 'TT',
			'name': 'Trinidad and Tobago'
	},
	{
			'code': 'TN',
			'name': 'Tunisia'
	},
	{
			'code': 'TR',
			'name': 'Turkey'
	},
	{
			'code': 'TM',
			'name': 'Turkmenistan'
	},
	{
			'code': 'TV',
			'name': 'Tuvalu'
	},
	{
			'code': 'UG',
			'name': 'Uganda'
	},
	{
			'code': 'UA',
			'name': 'Ukraine'
	},
	{
			'code': 'AE',
			'name': 'United Arab Emirates'
	},
	{
			'code': 'GB',
			'name': 'United Kingdom'
	},
	{
			'code': 'US',
			'name': 'United States'
	},
	{
			'code': 'UY',
			'name': 'Uruguay'
	},
	{
			'code': 'UZ',
			'name': 'Uzbekistan'
	},
	{
			'code': 'VU',
			'name': 'Vanuatu'
	},
	{
			'code': 'VA',
			'name': 'Vatican City'
	},
	{
			'code': 'VE',
			'name': 'Venezuela'
	},
	{
			'code': 'VN',
			'name': 'Vietnam'
	},
	{
			'code': 'YE',
			'name': 'Yemen'
	},
	{
			'code': 'ZM',
			'name': 'Zambia'
	},
	{
			'code': 'ZW',
			'name': 'Zimbabwe'
	}
];

export const Timezones = [
	'Africa/Abidjan',
	'Africa/Accra',
	'Africa/Addis_Ababa',
	'Africa/Algiers',
	'Africa/Asmara',
	'Africa/Bamako',
	'Africa/Bangui',
	'Africa/Banjul',
	'Africa/Bissau',
	'Africa/Blantyre',
	'Africa/Brazzaville',
	'Africa/Bujumbura',
	'Africa/Cairo',
	'Africa/Casablanca',
	'Africa/Ceuta',
	'Africa/Conakry',
	'Africa/Dakar',
	'Africa/Dar_es_Salaam',
	'Africa/Djibouti',
	'Africa/Douala',
	'Africa/El_Aaiun',
	'Africa/Freetown',
	'Africa/Gaborone',
	'Africa/Harare',
	'Africa/Johannesburg',
	'Africa/Juba',
	'Africa/Kampala',
	'Africa/Khartoum',
	'Africa/Kigali',
	'Africa/Kinshasa',
	'Africa/Lagos',
	'Africa/Libreville',
	'Africa/Lome',
	'Africa/Luanda',
	'Africa/Lubumbashi',
	'Africa/Lusaka',
	'Africa/Malabo',
	'Africa/Maputo',
	'Africa/Maseru',
	'Africa/Mbabane',
	'Africa/Mogadishu',
	'Africa/Monrovia',
	'Africa/Nairobi',
	'Africa/Ndjamena',
	'Africa/Niamey',
	'Africa/Nouakchott',
	'Africa/Ouagadougou',
	'Africa/Porto-Novo',
	'Africa/Sao_Tome',
	'Africa/Tripoli',
	'Africa/Tunis',
	'Africa/Windhoek',
	'America/Adak',
	'America/Anchorage',
	'America/Anguilla',
	'America/Antigua',
	'America/Araguaina',
	'America/Argentina/Buenos_Aires',
	'America/Argentina/Catamarca',
	'America/Argentina/Cordoba',
	'America/Argentina/Jujuy',
	'America/Argentina/La_Rioja',
	'America/Argentina/Mendoza',
	'America/Argentina/Rio_Gallegos',
	'America/Argentina/Salta',
	'America/Argentina/San_Juan',
	'America/Argentina/San_Luis',
	'America/Argentina/Tucuman',
	'America/Argentina/Ushuaia',
	'America/Aruba',
	'America/Asuncion',
	'America/Atikokan',
	'America/Bahia',
	'America/Bahia_Banderas',
	'America/Barbados',
	'America/Belem',
	'America/Belize',
	'America/Blanc-Sablon',
	'America/Boa_Vista',
	'America/Bogota',
	'America/Boise',
	'America/Cambridge_Bay',
	'America/Campo_Grande',
	'America/Cancun',
	'America/Caracas',
	'America/Cayenne',
	'America/Cayman',
	'America/Chicago',
	'America/Chihuahua',
	'America/Costa_Rica',
	'America/Creston',
	'America/Cuiaba',
	'America/Curacao',
	'America/Danmarkshavn',
	'America/Dawson',
	'America/Dawson_Creek',
	'America/Denver',
	'America/Detroit',
	'America/Dominica',
	'America/Edmonton',
	'America/Eirunepe',
	'America/El_Salvador',
	'America/Fort_Nelson',
	'America/Fortaleza',
	'America/Glace_Bay',
	'America/Godthab',
	'America/Goose_Bay',
	'America/Grand_Turk',
	'America/Grenada',
	'America/Guadeloupe',
	'America/Guatemala',
	'America/Guayaquil',
	'America/Guyana',
	'America/Halifax',
	'America/Havana',
	'America/Hermosillo',
	'America/Indiana/Indianapolis',
	'America/Indiana/Knox',
	'America/Indiana/Marengo',
	'America/Indiana/Petersburg',
	'America/Indiana/Tell_City',
	'America/Indiana/Vevay',
	'America/Indiana/Vincennes',
	'America/Indiana/Winamac',
	'America/Inuvik',
	'America/Iqaluit',
	'America/Jamaica',
	'America/Juneau',
	'America/Kentucky/Louisville',
	'America/Kentucky/Monticello',
	'America/Kralendijk',
	'America/La_Paz',
	'America/Lima',
	'America/Los_Angeles',
	'America/Lower_Princes',
	'America/Maceio',
	'America/Managua',
	'America/Manaus',
	'America/Marigot',
	'America/Martinique',
	'America/Matamoros',
	'America/Mazatlan',
	'America/Menominee',
	'America/Merida',
	'America/Metlakatla',
	'America/Mexico_City',
	'America/Miquelon',
	'America/Moncton',
	'America/Monterrey',
	'America/Montevideo',
	'America/Montserrat',
	'America/Nassau',
	'America/New_York',
	'America/Nipigon',
	'America/Nome',
	'America/Noronha',
	'America/North_Dakota/Beulah',
	'America/North_Dakota/Center',
	'America/North_Dakota/New_Salem',
	'America/Ojinaga',
	'America/Panama',
	'America/Pangnirtung',
	'America/Paramaribo',
	'America/Phoenix',
	'America/Port-au-Prince',
	'America/Port_of_Spain',
	'America/Porto_Velho',
	'America/Puerto_Rico',
	'America/Rainy_River',
	'America/Rankin_Inlet',
	'America/Recife',
	'America/Regina',
	'America/Resolute',
	'America/Rio_Branco',
	'America/Santarem',
	'America/Santiago',
	'America/Santo_Domingo',
	'America/Sao_Paulo',
	'America/Scoresbysund',
	'America/Sitka',
	'America/St_Barthelemy',
	'America/St_Johns',
	'America/St_Kitts',
	'America/St_Lucia',
	'America/St_Thomas',
	'America/St_Vincent',
	'America/Swift_Current',
	'America/Tegucigalpa',
	'America/Thule',
	'America/Thunder_Bay',
	'America/Tijuana',
	'America/Toronto',
	'America/Tortola',
	'America/Vancouver',
	'America/Whitehorse',
	'America/Winnipeg',
	'America/Yakutat',
	'America/Yellowknife',
	'Antarctica/Casey',
	'Antarctica/Davis',
	'Antarctica/DumontDUrville',
	'Antarctica/Macquarie',
	'Antarctica/Mawson',
	'Antarctica/McMurdo',
	'Antarctica/Palmer',
	'Antarctica/Rothera',
	'Antarctica/Syowa',
	'Antarctica/Troll',
	'Antarctica/Vostok',
	'Arctic/Longyearbyen',
	'Asia/Aden',
	'Asia/Almaty',
	'Asia/Amman',
	'Asia/Anadyr',
	'Asia/Aqtau',
	'Asia/Aqtobe',
	'Asia/Ashgabat',
	'Asia/Baghdad',
	'Asia/Bahrain',
	'Asia/Baku',
	'Asia/Bangkok',
	'Asia/Barnaul',
	'Asia/Beijing',
	'Asia/Beirut',
	'Asia/Bishkek',
	'Asia/Brunei',
	'Asia/Chita',
	'Asia/Choibalsan',
	'Asia/Colombo',
	'Asia/Damascus',
	'Asia/Dhaka',
	'Asia/Dili',
	'Asia/Dubai',
	'Asia/Dushanbe',
	'Asia/Gaza',
	'Asia/Hebron',
	'Asia/Ho_Chi_Minh',
	'Asia/Hong_Kong',
	'Asia/Hovd',
	'Asia/Irkutsk',
	'Asia/Jakarta',
	'Asia/Jayapura',
	'Asia/Jerusalem',
	'Asia/Kabul',
	'Asia/Kamchatka',
	'Asia/Karachi',
	'Asia/Kathmandu',
	'Asia/Khandyga',
	'Asia/Kolkata',
	'Asia/Krasnoyarsk',
	'Asia/Kuala_Lumpur',
	'Asia/Kuching',
	'Asia/Kuwait',
	'Asia/Macau',
	'Asia/Magadan',
	'Asia/Makassar',
	'Asia/Manila',
	'Asia/Muscat',
	'Asia/Nicosia',
	'Asia/Novokuznetsk',
	'Asia/Novosibirsk',
	'Asia/Omsk',
	'Asia/Oral',
	'Asia/Phnom_Penh',
	'Asia/Pontianak',
	'Asia/Pyongyang',
	'Asia/Qatar',
	'Asia/Qyzylorda',
	'Asia/Rangoon',
	'Asia/Riyadh',
	'Asia/Sakhalin',
	'Asia/Samarkand',
	'Asia/Seoul',
	'Asia/Shanghai',
	'Asia/Singapore',
	'Asia/Srednekolymsk',
	'Asia/Taipei',
	'Asia/Tashkent',
	'Asia/Tbilisi',
	'Asia/Tehran',
	'Asia/Thimphu',
	'Asia/Tokyo',
	'Asia/Tomsk',
	'Asia/Ulaanbaatar',
	'Asia/Urumqi',
	'Asia/Ust-Nera',
	'Asia/Vientiane',
	'Asia/Vladivostok',
	'Asia/Yakutsk',
	'Asia/Yekaterinburg',
	'Asia/Yerevan',
	'Atlantic/Azores',
	'Atlantic/Bermuda',
	'Atlantic/Canary',
	'Atlantic/Cape_Verde',
	'Atlantic/Faroe',
	'Atlantic/Madeira',
	'Atlantic/Reykjavik',
	'Atlantic/South_Georgia',
	'Atlantic/St_Helena',
	'Atlantic/Stanley',
	'Australia/Adelaide',
	'Australia/Brisbane',
	'Australia/Broken_Hill',
	'Australia/Currie',
	'Australia/Darwin',
	'Australia/Eucla',
	'Australia/Hobart',
	'Australia/Lindeman',
	'Australia/Lord_Howe',
	'Australia/Melbourne',
	'Australia/Perth',
	'Australia/Sydney',
	'Europe/Amsterdam',
	'Europe/Andorra',
	'Europe/Astrakhan',
	'Europe/Athens',
	'Europe/Belgrade',
	'Europe/Berlin',
	'Europe/Bratislava',
	'Europe/Brussels',
	'Europe/Bucharest',
	'Europe/Budapest',
	'Europe/Busingen',
	'Europe/Chisinau',
	'Europe/Copenhagen',
	'Europe/Dublin',
	'Europe/Gibraltar',
	'Europe/Guernsey',
	'Europe/Helsinki',
	'Europe/Isle_of_Man',
	'Europe/Istanbul',
	'Europe/Jersey',
	'Europe/Kaliningrad',
	'Europe/Kiev',
	'Europe/Kirov',
	'Europe/Lisbon',
	'Europe/Ljubljana',
	'Europe/London',
	'Europe/Luxembourg',
	'Europe/Madrid',
	'Europe/Malta',
	'Europe/Mariehamn',
	'Europe/Minsk',
	'Europe/Monaco',
	'Europe/Moscow',
	'Europe/Oslo',
	'Europe/Paris',
	'Europe/Podgorica',
	'Europe/Prague',
	'Europe/Riga',
	'Europe/Rome',
	'Europe/Samara',
	'Europe/San_Marino',
	'Europe/Sarajevo',
	'Europe/Simferopol',
	'Europe/Skopje',
	'Europe/Sofia',
	'Europe/Stockholm',
	'Europe/Tallinn',
	'Europe/Tirane',
	'Europe/Ulyanovsk',
	'Europe/Uzhgorod',
	'Europe/Vaduz',
	'Europe/Vatican',
	'Europe/Vienna',
	'Europe/Vilnius',
	'Europe/Volgograd',
	'Europe/Warsaw',
	'Europe/Zagreb',
	'Europe/Zaporozhye',
	'Europe/Zurich',
	'Indian/Antananarivo',
	'Indian/Chagos',
	'Indian/Christmas',
	'Indian/Cocos',
	'Indian/Comoro',
	'Indian/Kerguelen',
	'Indian/Mahe',
	'Indian/Maldives',
	'Indian/Mauritius',
	'Indian/Mayotte',
	'Indian/Reunion',
	'Pacific/Apia',
	'Pacific/Auckland',
	'Pacific/Bougainville',
	'Pacific/Chatham',
	'Pacific/Chuuk',
	'Pacific/Easter',
	'Pacific/Efate',
	'Pacific/Enderbury',
	'Pacific/Fakaofo',
	'Pacific/Fiji',
	'Pacific/Funafuti',
	'Pacific/Galapagos',
	'Pacific/Gambier',
	'Pacific/Guadalcanal',
	'Pacific/Guam',
	'Pacific/Honolulu',
	'Pacific/Johnston',
	'Pacific/Kiritimati',
	'Pacific/Kosrae',
	'Pacific/Kwajalein',
	'Pacific/Majuro',
	'Pacific/Marquesas',
	'Pacific/Midway',
	'Pacific/Nauru',
	'Pacific/Niue',
	'Pacific/Norfolk',
	'Pacific/Noumea',
	'Pacific/Pago_Pago',
	'Pacific/Palau',
	'Pacific/Pitcairn',
	'Pacific/Pohnpei',
	'Pacific/Port_Moresby',
	'Pacific/Rarotonga',
	'Pacific/Saipan',
	'Pacific/Tahiti',
	'Pacific/Tarawa',
	'Pacific/Tongatapu',
	'Pacific/Wake',
	'Pacific/Wallis',
	'UTC'
];

export const Languages = [
	{
			'name': 'English',
			'value': 'en'
	},
	{
			'name': '中文 (中国)',
			'value': 'zh_CN'
	},
	{
			'name': 'Dansk',
			'value': 'da'
	},
	{
			'name': 'Français',
			'value': 'fr'
	},
	{
			'name': 'ქართული',
			'value': 'ka'
	},
	{
			'name': 'Deutsch',
			'value': 'de'
	},
	{
			'name': 'Kreyòl ayisyen',
			'value': 'ht'
	},
	{
			'name': 'हिन्दी',
			'value': 'hi'
	},
	{
			'name': 'Íslenska',
			'value': 'is'
	},
	{
			'name': '日本語',
			'value': 'ja'
	},
	{
			'name': '한국어',
			'value': 'ko'
	},
	{
			'name': 'Português',
			'value': 'pt'
	},
	{
			'name': 'Español',
			'value': 'es'
	},
	{
			'name': 'Svenska',
			'value': 'sv'
	}
];

export const States = [
	{
			'name': 'Alabama',
			'code': 'AL'
	},
	{
			'name': 'Alaska',
			'code': 'AK'
	},
	{
			'name': 'Arizona',
			'code': 'AZ'
	},
	{
			'name': 'Arkansas',
			'code': 'AR'
	},
	{
			'name': 'California',
			'code': 'CA'
	},
	{
			'name': 'Colorado',
			'code': 'CO'
	},
	{
			'name': 'Connecticut',
			'code': 'CT'
	},
	{
			'name': 'Delaware',
			'code': 'DE'
	},
	{
			'name': 'District Of Columbia',
			'code': 'DC'
	},
	{
			'name': 'Florida',
			'code': 'FL'
	},
	{
			'name': 'Georgia',
			'code': 'GA'
	},
	{
			'name': 'Guam',
			'code': 'GU'
	},
	{
			'name': 'Hawaii',
			'code': 'HI'
	},
	{
			'name': 'Idaho',
			'code': 'ID'
	},
	{
			'name': 'Illinois',
			'code': 'IL'
	},
	{
			'name': 'Indiana',
			'code': 'IN'
	},
	{
			'name': 'Iowa',
			'code': 'IA'
	},
	{
			'name': 'Kansas',
			'code': 'KS'
	},
	{
			'name': 'Kentucky',
			'code': 'KY'
	},
	{
			'name': 'Louisiana',
			'code': 'LA'
	},
	{
			'name': 'Maine',
			'code': 'ME'
	},
	{
			'name': 'Maryland',
			'code': 'MD'
	},
	{
			'name': 'Massachusetts',
			'code': 'MA'
	},
	{
			'name': 'Michigan',
			'code': 'MI'
	},
	{
			'name': 'Minnesota',
			'code': 'MN'
	},
	{
			'name': 'Mississippi',
			'code': 'MS'
	},
	{
			'name': 'Missouri',
			'code': 'MO'
	},
	{
			'name': 'Montana',
			'code': 'MT'
	},
	{
			'name': 'Nebraska',
			'code': 'NE'
	},
	{
			'name': 'Nevada',
			'code': 'NV'
	},
	{
			'name': 'New Hampshire',
			'code': 'NH'
	},
	{
			'name': 'New Jersey',
			'code': 'NJ'
	},
	{
			'name': 'New Mexico',
			'code': 'NM'
	},
	{
			'name': 'New York',
			'code': 'NY'
	},
	{
			'name': 'North Carolina',
			'code': 'NC'
	},
	{
			'name': 'North Dakota',
			'code': 'ND'
	},
	{
			'name': 'Ohio',
			'code': 'OH'
	},
	{
			'name': 'Oklahoma',
			'code': 'OK'
	},
	{
			'name': 'Oregon',
			'code': 'OR'
	},
	{
			'name': 'Pennsylvania',
			'code': 'PA'
	},
	{
			'name': 'Puerto Rico',
			'code': 'PR'
	},
	{
			'name': 'Rhode Island',
			'code': 'RI'
	},
	{
			'name': 'South Carolina',
			'code': 'SC'
	},
	{
			'name': 'South Dakota',
			'code': 'SD'
	},
	{
			'name': 'Tennessee',
			'code': 'TN'
	},
	{
			'name': 'Texas',
			'code': 'TX'
	},
	{
			'name': 'Utah',
			'code': 'UT'
	},
	{
			'name': 'Vermont',
			'code': 'VT'
	},
	{
			'name': 'Virgin Islands',
			'code': 'VI'
	},
	{
			'name': 'Virginia',
			'code': 'VA'
	},
	{
			'name': 'Washington',
			'code': 'WA'
	},
	{
			'name': 'West Virginia',
			'code': 'WV'
	},
	{
			'name': 'Wisconsin',
			'code': 'WI'
	},
	{
			'name': 'Wyoming',
			'code': 'WY'
	}
];