
export interface IpInfo {
	ip: string;
	city: string;
	region: string;
	country: string;
	loc: string;
	org: string;
	postal: number;
	timezone: string;
	asn: {
			asn: string;
			name: string;
			domain: string;
			route: string;
			type: string;
	}
}