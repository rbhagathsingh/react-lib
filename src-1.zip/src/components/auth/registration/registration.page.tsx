import React, { useEffect, useState, FunctionComponent } from 'react';
import { useReadLocalStorage } from 'usehooks-ts';
import LoginWrapper from '../component/loginWrapper';
import { CountriesData, GenderData, Languages, MonthNames, States, Timezones } from './registration.mock';
import { Preloader } from '../../../shared/components';
import { useForm, Controller } from 'react-hook-form';
// import { Utils } from 'shared/utils';
import { IpInfo } from './registration.page.propTypes';
// import { useRegisterUserMutation } from '../../../store/api/auth.api';
import { RegisterUserFormFields, RegistrationPageProps } from '../models/auth.models';
import { useNavigate } from 'react-router-dom';
import { useRegisterUserMutation } from '../../../apiHooks/api.hooks';
import { GenericStorageConstants } from 'shared/constants';
import { UserDetails } from 'models';

/* eslint @typescript-eslint/no-unused-vars: "off" */

const RegistrationPage: FunctionComponent<RegistrationPageProps> = ({apiCallback, className}): JSX.Element => {
	const [userRegisterAPI, { isLoading: isRegisterLoading, data: registeredData }] = useRegisterUserMutation({});
	// const info: IpInfo = Utils.toJson(localStorage.getItem(GenericStorageConstants.IpInfo));
	const ipInfo: IpInfo | null = useReadLocalStorage(GenericStorageConstants.IpInfo);
	const userData: UserDetails | null = useReadLocalStorage(GenericStorageConstants.UserData);
	// const { registeredData } = useSelector((state: RootState) => state.auth);
	const navigate = useNavigate();
	
	const { handleSubmit, control, watch, formState: { errors } } = useForm({
		mode: 'onChange',
		defaultValues: {
			firstName: '',
			lastName: '',
			month: 0,
			date: '',
			year: '',
			gender: '',
			country: ipInfo?.country,
			state: '',
			timezone: ipInfo?.timezone,
			userLang: 'en'
		}
	});

	const [, setRegisterForm] = useState<RegisterUserFormFields>({
		firstName: '',
		lastName: '',
		month: '',
		date: '',
		year: '',
		gender: '',
		country: '',
		state: '',
		timezone: '',
		userLang: ''
	});
	watch('country');

	const [registrationStates] = useState({
		minYear: new Date().getFullYear() - 150,
		maxYear: new Date().getFullYear() - 16
	});

	const onSubmit = (data: any): void => {
		setRegisterForm(data);
		registerUserAPI(data);
	};

	const registerUserAPI = (data: RegisterUserFormFields): void => {
		// we need to check if ipInfo is getting passed or not when we check registration 
		// const ipInfo: IpInfo = Utils.toJson(localStorage.getItem(GenericStorageConstants.IpInfo));
		userRegisterAPI({
			data: {
				pii: {
					gender: data.gender,
					birthDate: `${data.year}-${data.month}-${data.date}`,
					firstName: data.firstName,
					lastName: data.lastName,
					addresses: [
						{
							country: data.country,
							state: data.state,
							zipCode: ipInfo?.postal || ''
						}
					]
				},
				language: data.userLang,
				timezone: data.timezone,
			},
			userId: userData?.id || ''
		});
	};

	const isError = (err: any, fieldName: string, type: string): boolean => {
			return (err && err[fieldName]) && err[fieldName].type === type;
	};

	const isErrors = (err: any, fieldName: string, type: string[]): boolean => {
		const arr = type.reduce((x: boolean[], ele) => {
			if (isError(err, fieldName, ele)) {
				x.push(true);
			}
			return x;
		}, []);
		return arr.length > 0;
	};

	useEffect(() => {
		if (registeredData) {
			if (apiCallback) {
				apiCallback({
					type: 'registration',
					data: registeredData
				})
			}
			navigate({
				pathname: '/'
			});
		}
	}, [registeredData]);

	useEffect(() => {
		document.body.classList.add('bg');
		return () => {
					document.body.classList.remove('bg');  
		};
	}, []);

	return (
		<LoginWrapper subTitle="Create Your Account" className={'registration-page' + (className ? ' ' + className : '')}>
			<React.Fragment>
				<form onSubmit={handleSubmit(onSubmit)} className="pt-3">
					<label htmlFor="password">My name is</label>
					<div className="row align-items-center mb-14">
						<div className="col">
							<Controller
								name="firstName"
								control={ control }
								render={({ field }) => <input className="form-control" id="firstName" type="text" {...field} />}
							/>
						</div>
						<div className="col">
							<Controller
								name="lastName"
								control={ control }
								render={({ field }) => <input className="form-control" id="lastName" type="text" {...field} />}
							/>
						</div>
					</div>
					<label htmlFor="password">My birthday is</label>
					<div className="row g-3 align-items-center mb-14">
						<div className={'col' + ((errors.month != null) && errors.month.type === 'required' ? ' has-error' : '')}>
							<Controller
									name="month"
									control={ control }
									rules={{ required: true }}
									render={({ field }) => <select className="form-control" {...field}> 
										{MonthNames.map((ele, ind) => {
											return <option key={ele} value={ind}>{ele}</option>;
										})}
									</select>}
							/>
							<div>Month</div>
						</div>
						<div className={'col' + ((errors.date != null) && errors.date.type === 'required' ? ' has-errpr' : '')}>
							<Controller
									name="date"
									control={ control }
									rules={{ required: true }}
									render={({ field }) => <input className="form-control" min={0} id="date" type="number" {...field} />}
							/>
							<div>Date</div>
						</div>
						<div className={'col' + (isErrors(errors, 'year', ['required']) ? ' has-error' : '')}>
							<Controller
									name="year"
									control={ control }
									rules={{ required: true }}
									render={({ field }) => <input className="form-control" id="date" type="number" maxLength={4} min={registrationStates.minYear} max={registrationStates.maxYear} {...field} />}
							/>
							<div>Year</div>
						</div>
					</div>
					{(errors.month || errors.date || errors.year) && (
						<div className="has-error birth-days-errors">
							{isError(errors, 'month', 'required') && (
								<div className="form-field-error">Month is required.</div>
							)}
							{isError(errors, 'date', 'required') && (
								<div className="form-field-error">Date is required.</div>
							)}
							{isError(errors, 'year', 'required') && (
								<div className="form-field-error">Year is required.</div>
							)}
						</div>
					)}
					
					<label htmlFor="password">My gender is</label>
					<div className="row g-3 align-items-center mb-14">
						<div className={'col' + (isErrors(errors, 'gender', ['required']) ? ' has-error' : '')}>
							<Controller
									name="gender"
									control={ control }
									rules={{ required: true }}
									render={({ field }) => <select className="form-control" {...field}> 
										<option value="">Please choose one ...</option> 
										{GenderData.map((ele) => {
											return <option key={ele.value} value={ele.value}>{ele.name}</option>;
										})}
									</select>}
							/>
							{isError(errors, 'gender', 'required') && (
								<div className="form-field-error">Gender is required.</div>
							)}
							
						</div>
					</div>
					<label htmlFor="country">I live in</label>
					<div className="row g-3 align-items-center mb-14">
						<div className="col">
							<Controller
									name="country"
									control={ control }
									rules={{ required: true }}
									render={({ field }) => <select className="form-control" {...field}> 
										{CountriesData.map((ele, ind) => {
											return <option key={ele.code + ind} value={ele.code}>{ele.name}</option>;
										})}
									</select>}
							/>
						</div>
					</div>
					{control._formValues.country === 'US' && (
						<React.Fragment>
							<label htmlFor="password">State</label>
							<div className="row g-3 align-items-center mb-14">
								<div className="col">
									<Controller
										name="state"
										control={ control }
										rules={{ required: true }}
										render={({ field }) => <select className="form-control" {...field}> 
											{States.map((ele, ind) => {
												return <option key={ele.code + ind} value={ele.name}>{ele.name}</option>;
											})}
										</select>}
									/>
								</div>
							</div>
						</React.Fragment>
					)}
					
					<label htmlFor="password">My timezone is</label>
					<div className="row g-3 align-items-center mb-14">
						<div className="col">
							<Controller
									name="timezone"
									control={ control }
									rules={{ required: true }}
									render={({ field }) => <select className="form-control" {...field}> 
										{Timezones.map((ele, ind) => {
											return <option key={ele + ind} value={ele}>{ele}</option>;
										})}
									</select>}
							/>
						</div>
					</div>
					<label htmlFor="password">My Preferred Language is</label>
					<div className="row g-3 align-items-center mb-14">
						<div className="col">
							<select className="form-control"> 
								{Languages.map((ele, ind) => {
									return <option key={ele.value + ind} value={ele.value}>{ele.name}</option>;
								})}
							</select>
						</div>
					</div>
					<div className="d-grid gap-2  pb-4 pt-3">
						<button disabled={isRegisterLoading} className="btn btn-primary login-btn d-flex justify-content-center align-items-center" type="submit">
							<span>Continue</span>
							{isRegisterLoading && (
								<Preloader/>
							)}
						</button>
					</div>
				</form>
			</React.Fragment>
		</LoginWrapper>
	);
}

export default RegistrationPage;