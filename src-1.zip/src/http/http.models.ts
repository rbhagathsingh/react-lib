/* eslint  @typescript-eslint/naming-convention: 0 */
/* eslint  @typescript-eslint/array-type: 0 */
export interface ObjectKeyPair {
    [key: string]: any;
}

export type API_METHODS = 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELET';
export type AxiosParamsData = Array<any>;
export type AxiosQueryPramsArray = [any, any];

export interface AxiosHttpPayload {
    queryParams?: ObjectKeyPair;
    queryParamsArray?: AxiosQueryPramsArray[];
    paramsData?: AxiosParamsData[];
    data?: any;
    baseURL?: string;
    apiBaseUrl?: string | null;
    [key: string]: any;
}