/* eslint @typescript-eslint/promise-function-async: 0 */
/* eslint unicorn/no-array-for-each: 0 */
/* eslint unicorn/prefer-ternary: 0 */
import axios, { AxiosStatic } from 'axios';
import { AxiosHttpPayload } from './http.models';

 class HttpClient {
    static apiBaseUrl = '';

    static setAPIBaseURL(opt: { baseURL: string; apiBaseURL?: string }): void {
        this.apiBaseUrl = opt.apiBaseURL || '';
        axios.defaults.baseURL = opt.baseURL;
    }

    static getAxios(): AxiosStatic {
        return axios;
    }

    static get(url: string, payload?: AxiosHttpPayload): Promise<any> {
       return axios(this.payload('GET', url, payload));
    }

    static post(url: string, payload?: AxiosHttpPayload): Promise<any> {
        return axios(this.payload('POST', url, payload));
    }

    static put(url: string, payload?: AxiosHttpPayload): Promise<any> {
        return axios(this.payload('PUT', url, payload));
    }

    static patch(url: string, payload?: AxiosHttpPayload): Promise<any> {
        return axios(this.payload('PATCH', url, payload));
    }

    static delete(url: string, payload?: AxiosHttpPayload): Promise<any> {
        return axios(this.payload('DELETE', url, payload));
    }

    static payload(method: string, url: string, payloadObj?: AxiosHttpPayload): any {
        const mapPayload = payloadObj || {};
        const obj = { ...mapPayload };

        const URI = this.buildUrl(url, payloadObj || {});
        
        const payload = {
            url: URI,
            method,
            ...obj
        };
        return payload;
    }

    static buildUrl(url: string, payload: AxiosHttpPayload): string {
        const URI = payload.apiBaseUrl === null ? url : ((payload.apiBaseUrl || HttpClient.apiBaseUrl) + url)

        let params = URI;
        const payloadObj = payload || {};
        if (payloadObj.paramsData) {
            payload.paramsData?.forEach((ele: any[]) => {
                params = this.mapParams(params, ele[0], ele[1]);
            });
        }

        if (payloadObj.queryParams) {
            params += this.buildQuery(payload.queryParams);
        }

        if (payloadObj.queryParamsArray) {
            params += this.buildQuery(payload.queryParamsArray);
        }
        return params;
    }

    static mapParams(url: string, str: string, val: string): string {
        return url.replace(str, val);
    }

    private static buildQuery(obj: any): string {
        let str = '';
        let count = 0;

        if (Array.isArray(obj)) {
            obj.forEach((ele, ind) => {
                if (ind === 0) {
                    str += `?${ele[0]}=${ele[1]}`;
                } else {
                    str += `&${ele[0]}=${ele[1]}`;
                }
            });
            return str;
        }

        for (const key in obj) {
           if (count === 0) {
            str += `?${key}=${obj[key]}`;
           } else {
            str += `&${key}=${obj[key]}`;
           }
           count++;
        }
        return str;
    }
}

export default HttpClient;