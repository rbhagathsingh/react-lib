import axios from 'axios';
// import { useReadLocalStorage } from 'usehooks-ts';
import { Utils } from '../shared/utils';
import { GenericStorageConstants } from 'shared/constants';
/* eslint @typescript-eslint/dot-notation: 0 */
/* eslint @typescript-eslint/promise-function-async: 0 */
function apiInterceptor(): void {
  axios.interceptors.request.use(function (config: any) {
    const token: any = Utils.toJson(localStorage.getItem(GenericStorageConstants.Token));
    // const token: any = useReadLocalStorage(GenericStorageConstants.Token);
    if (token) {
      config.headers['Authorization'] = 'Bearer ' + Utils.trimDoubleQuote(token.token);
    }
      return config;
    }, function (error) {
      return Promise.reject(error);
  });
  
  // Add a response interceptor
  axios.interceptors.response.use(function (response) {
      return response;
    }, function (error) {
      return Promise.reject(error);
  });
}

export default apiInterceptor;
