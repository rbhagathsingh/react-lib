import AxiosHttpInterCepter from './httpInterceptor';
export { default as HttpClient } from './http';
export * from './http.models';

AxiosHttpInterCepter();
