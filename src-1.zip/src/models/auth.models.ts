export interface AuthSignupAPIPayload {
	registration: {
		username: string;
    plainPassword: string;
    fullname: string;
	},
	client_id: string;
  client_secret: string;
  usedHost: string;
};

export interface OAuthAPIPayload {
	username: string;
  password: string;
  remember_me?: number | boolean;
  client_id: string;
  client_secret: string;
  grant_type: string;
}

export interface OAuthAPIResponse {
	access_token: string;
  expires_in: number
  token_type: string;
  scope: any
}

export interface RegisterUserPayload {
  pii: {
    gender: string;
    birthDate: string;
    addresses: {
			zipCode: string | number;
			country: string;
			state: string;
		}[],
    firstName: string;
    lastName: string;
  },
  timezone: string;
  language: string;
};

export interface RegisterUserFormFields {
		firstName: string;
		lastName: string;
		month: string;
		date: string;
		year: string;
		gender: string;
		country: string;
		state: string;
		timezone: string;
		userLang: string;
};


export interface ResetPasswordPayload {
	username: string;
  resetLink: string;
  client_id: string;
  client_secret: string;
  usedHost: string;
}

export interface LoginPayload {
	client_id: string;
	client_secret: string;
	grant_type: string;
	username: string;
	password: string;
	remember_me?: string;
}

export interface LoginFormFields {
	email?: string;
	password?: string;
	rememberMe?: string;
}


export interface Site {
	study: number;
	id: number;
	identifier: number;
	name: string;
	address: string;
	calendarId: number;
	translations: any;
}


export interface Sites {
	id: number; 
	site: Sites[]
}

export interface UserAddress {
	id: number;
	country: string;
	street: string;
	city: string;
	state: string;
	zipCode: string;
	description: string;
	latitude: number;
	longitude:  number;
	translations: any
}

export interface UserPhones {
	id?: number;
	number: string;
	verified?: boolean;
	status?: string;
}

export interface UserEmails{
	email: string;
	status?: string;
	verified?: boolean;
}

export interface UserDetails {
	fullname: string;
	hasMinFieldsParticipant: boolean;
	hasMinFieldsResearcher: boolean;
	primaryEmail: string;
	language: string;
	primaryPhone: number;
	isSuperAdmin: boolean;
	hasPassword: boolean;
	rememberMe: number;
	emailTaskAlerts: number;
	smsTaskAlerts: number;
	weeklyEmailSummary: number;
	hasOrderAccess: any;
	id: string | number;
	audienceType: string;
	sites: Sites[];
	pii: {
			addresses:UserAddress[];
			phones: UserPhones[];
			emails: UserEmails[];
			firstName: string;
			lastName: string;
			title: string;
			gender: string;
			birthDate: string;
			sexWith: string;
			annualIncome: string;
			children: number;
			educationLevel: string;
			industry: string;
			maritalStatus: string;
			raceUser: [],
			
			organization: string;
			licenseNumber: string;
			licenseExpiresOn: string;
			translations: string;
	};
	notifyPreference: {
			[key: string]: {
					email: boolean;
					facebook: boolean;
					push: boolean;
					sms: boolean;
					weekly_email: boolean;
			}
	}
}

export interface ServeParticipantPayload {
	userPassword: string;
}

export interface ContactPreferencesPayload {
	email_task_alerts?: number | string;
	emailTaskAlerts?: number | string;
	language: string;
	sms_task_alerts?: number | string;
	smsTaskAlerts?: number | string;
	weekly_email_summary?: number | string;
	weeklyEmailSummary?: number | string;
	timezone: string;
	notifyPreference?: {
		[key: string]: {
			email: boolean;
			facebook: boolean;
			push: boolean;
			sms: boolean;
			weekly_email: boolean;
		}
	};
	pii: {
		firstName: string;
		lastName: string;
		phones: UserPhones[];
		emails: UserEmails[];
		licenseNumber: string | null;
		licenseExpiresOn: string | null;
	}
};