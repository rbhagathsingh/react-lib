export interface LoginProps {
    signUp?: () => void;
    loggedIn?: (res: UserDetails) => void;
    socialLoginSubmit?: (val:any) => void;
    resetPage?: () => void;
    authConfig?: {
        clientId: string;
        clientSecret: string;
        grantType: string;
        apiBaseUrl: string;
    }
    pageType: 'patient' | 'sponser' | 'site'
}

export interface SignupProps {
    loginPage?: () => void;
    authConfig?: {
        clientId: string;
        clientSecret: string;
        grantType: string;
        appType: string;
    }
}

export interface ResetProps {
    resetCallBack:(data: any) => any;
    loginPage?: () => void;
    authConfig?: {
        clientId: string;
        clientSecret: string;
        grantType: string;
    }
}

export interface ExistUserResponse {
    isUserExists: boolean;
    audienceType: number,
    hasEmail: boolean;
    hasPhone: boolean;
    isPasswordreset: boolean;
    lastLogin: string | Date;
    isPasswordSet: boolean;
}

export interface Site {
    study: number;
    id: number;
    identifier: number;
    name: string;
    address: string;
    calendarId: number;
    translations: any;
}


export interface Sites {
    id: number; 
    site: Sites[]
}

export interface UserAddress {
    id: number;
    country: string;
    street: string;
    city: string;
    state: string;
    zipCode: string;
    description: string;
    latitude: number;
    longitude:  number;
    translations: any
}

export interface UserPhones {
    id: number;
    number: string;
    verified: boolean;
    status: string;
}

export interface UserEmails{
    email: string;
    status: string;
    verified: boolean;
}

export interface UserDetails {
    fullname: string;
    hasMinFieldsParticipant: boolean;
    hasMinFieldsResearcher: boolean;
    primaryEmail: string;
    language: string;
    primaryPhone: number;
    isSuperAdmin: boolean;
    hasPassword: boolean;
    rememberMe: number;
    emailTaskAlerts: number;
    smsTaskAlerts: number;
    weeklyEmailSummary: number;
    hasOrderAccess: any;
    id: number;
    audienceType: string;
    sites: Sites[];
    pii: {
        addresses:UserAddress[];
        phones: UserPhones[];
        emails: UserEmails[];
        firstName: string;
        lastName: string;
        title: string;
        gender: string;
        birthDate: string;
        sexWith: string;
        annualIncome: string;
        children: number;
        educationLevel: string;
        industry: string;
        maritalStatus: string;
        raceUser: [],
        
        organization: string;
        licenseNumber: string;
        licenseExpiresOn: string;
        translations: string;
    };
    notifyPreference: {
        [key: string]: {
            email: boolean;
            facebook: boolean;
            push: boolean;
            sms: boolean;
            weekly_email: boolean;
        }
    }
}


