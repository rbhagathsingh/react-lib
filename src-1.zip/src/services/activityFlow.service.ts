import { HttpClient } from '../http';
import { Utils } from 'shared';
import { GenericStorageConstants } from 'shared/constants';
import UserService from './userService';
import { API } from 'shared/constants/api.constants';

class ActivityFlowService {
    private static tasksConfig = UserService.taskConfig();
    /**
     * Service resolves next url and route state
     * @param task
     * @returns {any}
     */

    public static getRouteStateByTask(task:any) {
        switch (task.type) {
            case this.tasksConfig.taskTypes.infographic:
            case this.tasksConfig.taskTypes.invite:
            case this.tasksConfig.taskTypes.visit:
            case this.tasksConfig.taskTypes.simpleInteraction:
            case this.tasksConfig.taskTypes.consent:
            case this.tasksConfig.taskTypes.survey:
            case this.tasksConfig.taskTypes.video:
            case this.tasksConfig.taskTypes.onlineActivity:
            case this.tasksConfig.taskTypes.auth:
            case this.tasksConfig.taskTypes.gang:
            case this.tasksConfig.taskTypes.upload:
            case this.tasksConfig.taskTypes.product:
            case this.tasksConfig.taskTypes.appointment:
            case this.tasksConfig.taskTypes.photoAssessment:
                return 'beginParticipantTask';
            case this.tasksConfig.taskTypes.landingPageInsight:
                return 'userSubLayout-insight';
            case this.tasksConfig.taskTypes.PromoCode:
            case this.tasksConfig.taskTypes.giftCard:
                return 'userSubLayout.reward';
        }

        return null;
    }

    /**
     * Resolve next URI
     * @param currentActivity
     * @param isServe
     * @return {IPromise<string>}
     */
    public static getNextURL(currentActivity:any, isServe:any = false) {
        const userData = Utils.getLocalStore(GenericStorageConstants.UserData);
        if (currentActivity._embedded && currentActivity._embedded.nextGroupActivities || currentActivity._embedded && currentActivity._embedded.nextActivities) {

            let activities = currentActivity._embedded.nextGroupActivities || currentActivity._embedded.nextActivities;
            if (activities.length > 0) {
                let activity = activities[0];
                let route = this.getRouteStateByTask(activity);
                if (isServe === false && activity.task.proctorDefinition == null) {
                    //return Promise.resolve(route ? this.$state.go(route, {id: activity.id}) : '/');
                    return Promise.resolve({
                        url: route ? `${route}/${activity.id}` : '/',
                    });
                } else {
                    return Promise.resolve({
                        url:'/',
                    });
                }
            }
        }

        let checkIfNextTaskInSameGroup = function (activity) {

            if(currentActivity.studyUser.arm.id !== activity.studyUser.arm.id){
                return true;
            }

            if (!activity.task.group || !currentActivity.task.group) {
                return false;
            }

            return ((activity.task.group.id && (
                activity.task.group.id === currentActivity.task.group.id
            )) || currentActivity.task.group === 'any');

        };


        let resolveUrl = () => {
            return (<any>window).FECommon.pokemon((activities) => {
                if (isServe) {
                    activities.data = activities;
                }
                if (activities.data && activities.data.length) {
                    let activity;
                    for (let i = 0; i < activities.data.length; i++) {
                        activity = activities.data[i];

                        if (activity.status === 'completed') {
                            continue
                        }
                        if(activity.task.dataUploadTask){
                            continue;
                        }
                        if(activity.task.type == 'Product' && activity.task.isAutoProcess) {
                            return false;
                        }
                        if(activity.task.type==='Eligibility' || activity.task.type==='ArmAssign' || activity.task.type==='Decision'){

                            if(activity.messages.length > 0){
                                let activitymessage= activity.messages[0].message;
                                sessionStorage.setItem('activitymessage', activitymessage);
                                return Promise.resolve({
                                    url: '/'
                                });
                            }

                        }
                        if (activity.task.study != currentActivity.task.study) { // != because data can be int or str
                            continue
                        }
                        if (checkIfNextTaskInSameGroup(activity)) {
                            let route = this.getRouteStateByTask(activity);
                            if (route) {
                               return Promise.resolve({
                                url: route ? `${route}/${activity.id}` : '/'
                               });
                            }
                        }
                    }
                }

                if (isServe) {
                    return Promise.resolve('/serve/search/enter-code');
                } else {
                    return '/';
                }
            });
        };

        let resolveUrlForProctor = (studyId) => {
            return (<any>window).FECommon.pokemon((activities) => {
                if (isServe) {
                    activities.data = activities;
                }
                if (activities.data && activities.data.length) {
                    let activity;
                    for (let i = 0; i < activities.data.length; i++) {
                        activity = activities.data[i];

                        if (activity.status === 'completed') {
                            continue
                        }
                        if (activity.task.study != currentActivity.task.study) { // != because data can be int or str
                            continue
                        }
                        if (checkIfNextTaskInSameGroup(activity)) {
                            if(!activity.task.proctorDefinition) {
                                return Promise.resolve('/serve/search/enter-code');
                            }
                            let route = this.getRouteStateByTask(activity);
                            if (route) {
                                return Promise.resolve(route ? `${route}/${activity.id}` : '/');
                            }
                        }
                    }
                }
                if (isServe) {
                    return Promise.resolve('/serve/search/enter-code');
                } else {
                    return Promise.resolve(`/share/${studyId}`);
                }
            });
        };

        if (currentActivity.studyUser.userId && (userData.id !== currentActivity.studyUser.userId)) {
            return HttpClient.get(API.ProctorUser, {
                apiBaseUrl: '/api/v3',
                paramsData: [
                    ['[proctorId]', userData.id]
                ],
                queryParams: {
                    'filters[participant_id]': currentActivity.task.study
                }
            }).then(() => resolveUrlForProctor(currentActivity.task.study))
        } else {
            let accessCode = localStorage.getItem('accessCode');
            let participant = localStorage.getItem('participant');
            if (isServe) {
               return HttpClient.get(API.ProctorActivities, {
                    apiBaseUrl: '/api/v3',
                    paramsData: [
                        ['[participant]', participant],
                        ['[key]', accessCode],
                    ]
                }).then(() => resolveUrlForProctor(currentActivity.task.study))
            } else {
               return HttpClient.get(API.Activities, {
                    apiBaseUrl: '/api/v3',
                    paramsData: [
                        ['[activityId]', participant]
                    ],
                }).then(() => resolveUrl())
            }
        }

    }
}


export default ActivityFlowService;