import UserService from "./userService";
class LoginUtil {
    private static emailRegExp = /((^[a-zA-Z\-\][\w.+]+@(proofpilot|cyclogram)\.com$)|(^([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5})$))/;
    private static phoneRegExp = /^\+?\d{8,20}$/;

    static validateLogin(login: any): 'email' | 'phone' | '' {
        if (this.emailRegExp.test(login)) return 'email';
        var l = login.replace(/[^\w]+/g, '');
        if (this.phoneRegExp.test(l)) return 'phone';
        return '';
    }

    static formatPhone(phone: any) {
        var login = this.fixPhone(phone);
        return login.replace(/(\+\d+)?(\d{3})(\d{3})(\d{4})/, '$1 ($2) $3-$4').trim();
    }

    static fixPhone(l: string) {
        if(this.validateLogin(l) != 'phone') return l;
        var login = l.replace(/[^\w\+]+/g,'');
        if(login.indexOf('+') == 0) return login;
        var code = UserService.getCountryCode();
        if(code) {
            return code + login;
        }
        return login;
    }

}

export default LoginUtil;