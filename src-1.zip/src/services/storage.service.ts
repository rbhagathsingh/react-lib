
class StorageService { 
    static _prefix = 'ProofPilot-';
    static getItem(name: string) {
        let text = localStorage.getItem(this._getKey(name));
        if(text) {
            return JSON.parse(text);
        }
        return text;
    }
    
    static setItem(name:string, value: any) {
        let serialized = value ? JSON.stringify(value) : value;
        if(serialized) {
            localStorage.setItem(this._getKey(name), JSON.stringify(value));
        } else {
            localStorage.setItem(this._getKey(name), value);
        }
    }

    static hasItem(name: string) {
        return localStorage.getItem(this._getKey(name)) !== null;
      }

    static clear(name: string) {
        localStorage.removeItem(this._getKey(name));
      }

    static clearAll() {
        localStorage.clear();
      }

   static _getKey(name: string) {
        return this._prefix + name;
      }
}
export default StorageService;
