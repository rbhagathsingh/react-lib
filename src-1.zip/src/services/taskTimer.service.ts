import { API } from "shared/constants/api.constants";
import { HttpClient } from "../http";

 class TaskTimerService {
    private static timers = {};
    
    public static start(id){
        this.timers[id] = Date.now();
    };

    public static stop(id){
        const s = this.timers[id];
        if(!s) {
            console.log('Tried to stop timer for task ' + id + ' but there were none');
            return;
        }
        delete this.timers[id];
        const elapsed = (Date.now() - s);

        HttpClient
			.get(API.TaskMetrics, { apiBaseUrl: '/api/v3' })
			.then((res) => {
				const average = res.averageCompletionTime;
                const count = res.usersCompleted;
                HttpClient.patch(API.TaskMetrics, {
                    data: {
                        averageCompletionTime: (average * count + elapsed) / (count + 1),
                        usersCompleted: count + 1
                    },
                    paramsData: [['[id]', id]]
                });
			})
			.catch((error) => {
                console.log('@@@ TaskMetrics ERRORS', error);
				if(error.status == 404) {
                    HttpClient.post(API.TaskMetrics, {
                        data: {
                            usersCompleted: 1,
                            averageCompletionTime: elapsed
                        },
                        paramsData: [['[id]', id]]
                    });
                };
			})
    };
 }

 export default TaskTimerService;