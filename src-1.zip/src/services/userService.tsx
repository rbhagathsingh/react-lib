
import StorageService from "./storage.service";
import EXISING_COUNTRY_CODES from '../configs/exisitinCountryCodes.json';
import COUNTRY_CODES from '../configs/countryCodes.json';
import TASK_CONFIGS from '../configs/taskConfigs.json';

class UserService {
    private static COUNTRY_CODES: any = Object.assign(EXISING_COUNTRY_CODES, COUNTRY_CODES);
    static getCountryCode() {
        let ipinfo = StorageService.getItem('ipinfo');
        if (ipinfo) {
            return this.COUNTRY_CODES[ipinfo.country]
        } else {
            return null;
        }
    }

    public static taskConfig() {
        return TASK_CONFIGS
    }
}

export default UserService;
