import { PropsWithChildren, ReactElement } from "react";

export interface AlertConfirmComponentButtons {
    name: string,
}
export interface AlertConfirmComponentProps extends PropsWithChildren {
    isOpen: boolean;
    transitionType?: 'up' | 'down';
    title?: string;
    className?: string;
    type?: 'alert' | 'confirm' | 'custom';
    confirmButtonsText?: string[];
    renderTitle?: () => ReactElement;
    renderContent?: () => ReactElement;
    renderButtons?: () => ReactElement;
    buttons?: AlertConfirmComponentButtons[];
    onBtnClick?: (val: any) => void;
    onAlertClose?: (val: any) => void;
}