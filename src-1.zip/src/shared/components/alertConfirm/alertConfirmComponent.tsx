import React, { useCallback, useState, FunctionComponent, useEffect } from 'react';
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';

import DialogTitle from '@mui/material/DialogTitle';
import Slide from '@mui/material/Slide';
import { TransitionProps } from '@mui/material/transitions';
import { AlertConfirmComponentButtons, AlertConfirmComponentProps } from './alertConfirmComponent.model';

const TransitionDown = React.forwardRef(function Transition(
    props: TransitionProps & {
      children: React.ReactElement<any, any>;
    },
    ref: React.Ref<unknown>,
  ) {
    return <Slide direction="down" ref={ref} {...props} />;
  });

  const TransitionUp = React.forwardRef(function Transition(
    props: TransitionProps & {
      children: React.ReactElement<any, any>;
    },
    ref: React.Ref<unknown>,
  ) {
    return <Slide direction="up" ref={ref} {...props} />;
  });

const AlertConfirmComponent: FunctionComponent<AlertConfirmComponentProps> = (props: AlertConfirmComponentProps): JSX.Element => {
    const [alertConfirmButtons, setAlertConfirmButtons] = useState<any>({
        alert: [{ name: 'Ok' }],
        confirm: [{ name: 'Cancel' }, { name: 'Confirm' }],
    });

  const buttonHandler = useCallback((val: string) => {
    if (props.onBtnClick) {
        props.onBtnClick(val.toLowerCase());
    }
  }, []);

  const onCloseHandler = useCallback(() => {
    if (props.onAlertClose) {
        props.onAlertClose('backdrop');
    }
  }, []);

  useEffect(() => {
    if(props.confirmButtonsText?.length === 2) {
      setAlertConfirmButtons((prev) => {
        const obj = { ...prev };
        obj.confirm[0].name = props.confirmButtonsText ? props.confirmButtonsText[0]: ''
        obj.confirm[1].name = props.confirmButtonsText ? props.confirmButtonsText[1]: ''
        return obj;
      })
    }
  }, []);

    return (
	<Dialog
            open={props.isOpen}
            TransitionComponent={ props.transitionType === 'up' ? TransitionUp : TransitionDown}
            keepMounted
            className={'alert-confirm-popup' + (props.className || '')}
            onClose={onCloseHandler}
            aria-describedby="alert-dialog-slide-description"
        >
		<DialogTitle>
			{props.title && (props.title)}
			{props.renderTitle && (props.renderTitle())}
		</DialogTitle>
		<DialogContent>
			{/* <DialogContentText id="alert-dialog-slide-description"> */}
			{props.children && (props.children)}
			{props.renderContent && (props.renderContent())}
			{/* </DialogContentText> */}
		</DialogContent>
		<DialogActions>
			{!props.renderButtons && !props.type && (
                    alertConfirmButtons.alert.map((ele: AlertConfirmComponentButtons) => {
                        return <Button key={ele.name} onClick={ () => { buttonHandler(ele.name); }}>{ele.name}</Button>;
                    })
                )}
			{!props.renderButtons && props.type && props.type !== 'custom' && (
                    alertConfirmButtons[props.type || ''].map((ele: AlertConfirmComponentButtons) => {
                        return <Button key={ele.name} onClick={ () => { buttonHandler(ele.name); }}>{ele.name}</Button>;
                    })
                )}

			{!props.renderButtons && props.type && props.type === 'custom' && (
                    (props.buttons || []).map((ele: AlertConfirmComponentButtons) => {
                        return <Button key={ele.name} onClick={ () => { buttonHandler(ele.name); }}>{ele.name}</Button>;
                    })
                )}

			{props.renderButtons && props.renderButtons()}
		</DialogActions>
	</Dialog>
    );
}

export default AlertConfirmComponent;