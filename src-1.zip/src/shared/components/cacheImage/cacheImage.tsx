import React, { FunctionComponent } from 'react';

const imgCache: any = {
  __cache: {},
  read(src: string): any {
    if (!src) {
      return;
    }

    if (!this.__cache[src]) {
      this.__cache[src] = new Promise((resolve) => {
        const img = new Image();
        img.addEventListener('load', () => {
            this.__cache[src] = true;
            resolve(this.__cache[src]);
        });
        img.src = src;
        setTimeout(() => resolve({}), 7000);
      }).then(() => {
        this.__cache[src] = true;
      });
    }

    if (this.__cache[src] instanceof Promise) {
      throw this.__cache[src];
    }
    return this.__cache[src];
  },
  clearImg(src: string) {
    delete this.__cache[src];
  }
};

const CacheImg: FunctionComponent<{ src: string; alt?: any; className?: string }> = ({ src, ...rest }): JSX.Element => {
  imgCache.read(src);
  return <img alt={rest.alt || ''} src={src} {...rest} />;
};

export default CacheImg;
