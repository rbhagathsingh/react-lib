import React, { forwardRef, useEffect, useImperativeHandle, useRef } from 'react';
import { Controller } from 'react-hook-form';
import Utils from '../../utils/utils';
import { FormFieldProps } from './formFieldPropTypes';

const getErrorKeys = (res: any): string[] => {
	const rules = (res || {});
	const type: string[] = [];
	Utils.eachKeyValue(rules, (value, key) => {
			if (key === 'validate') {
				Utils.eachKeyValue(rules.validate, (val, k) => {
					type.push(k);
				});
			} else {
				type.push(key);
			}
	});
	return type;
};

const FormField = forwardRef((props: FormFieldProps, ref: any): JSX.Element => {
	const formFieldRef = useRef<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>();
	const fieldEle = useRef<HTMLDivElement>(null);
	const errorTypes = getErrorKeys(props.rules);
	const isError = (err: any, fieldName: string, type: string): boolean => {
		return (err && err[fieldName]) && err[fieldName].type === type;
	};

	const isErrors = (err: any, fieldName: string, type: string[]): boolean => {
		const arr = type.reduce((x: boolean[], ele) => {
			if (isError(err, fieldName, ele)) {
				x.push(true);
			}
			return x;
		}, []);
		return arr.length > 0 || (props.customValidate || false);
	};

	const changeInput = (evt: any): string => {
		if (props.inputChange) {
			return props.inputChange(evt);
		}
		return evt.target.value;
	};

	const inputs = (field: any, refData: any): JSX.Element => {
		if (props.inputType === 'select') {
			return <select className="form-control" {...field} ref={refData}> 
				{(props.selectData || []).map((ele, ind) => {
					return <option key={ele[props.selectDataIdKey || ''] + ind} value={ele[props.selectDataIdKey || '']}>{ele[props.selectDataLabelKey || '']}</option>;
				})}
			</select>;
		} else if (props.inputType === 'textarea') {
		return <textarea ref={refData} className="form-control" placeholder={props.placeholder} rows={4} {...field} onChange={(evt) => {
				field.onChange(changeInput(evt));
		}}></textarea>;
		} else {
			return <input className="form-control" ref={refData} id="password" type={props.inputType || 'text'} placeholder={props.placeholder} {...field} onChange={(evt) => {
					field.onChange(changeInput(evt));
			}} />;
		}
	};

	useImperativeHandle(ref, () => ({
        input: formFieldRef.current,
		ele: fieldEle.current
    }), [formFieldRef.current, fieldEle.current]);

	useEffect(() => {
		console.log('@@@ INNNPUT', formFieldRef);
	}, [formFieldRef])

	return (
		<div ref={fieldEle} className={'mb-14' + (isErrors(props.errors, props.fieldName, errorTypes) ? ' has-error' : '')}>
			{props.label && <label htmlFor="password">{props.label}</label> }
			<Controller
					name={props.fieldName}
					control={ props.control }
					rules={props.rules || {}}
					render={({ field }) => (inputs(field, formFieldRef))}
			/>
			{props.children && props.children}
			{!props.children && (
				errorTypes.map((ele) => {
					if (props.errors && props.errors[props.fieldName] && props.errors[props.fieldName].type === ele) {
						return <div key={ele} className="form-field-error">{(props.errorMessages || {})[props.errors[props.fieldName].type]}</div>;
					}
					return '';
				})
			)}
			{props.customChildren && props.customChildren()}
		</div>
	);
});

export default FormField;