import { PropsWithChildren } from "react";

export interface FormFieldProps extends PropsWithChildren {
	errors: any;
	control: any;
	inputType?: 'text' | 'number' | 'password' | 'select' | 'textarea';
	rules?: any;
	label?: string;
	fieldName: string;
	placeholder?: string;
	selectData?: any[];
	selectDataIdKey?: string;
	selectDataLabelKey?: string;
	errorMessages?: {[key: string]: any};
	customValidate?: boolean;
	inputChange?: (val: any) => any;
	customChildren?: (val?: any) => any;
}