import React from 'react';
function IconComponent(props:any) {
    let clasName = (props.name || 'menu-dot') + ' ';
    if(props.className) {
        clasName += props.className
    }
    return (
        <span className={'icon-' + clasName }></span>
    );
}

export default IconComponent;