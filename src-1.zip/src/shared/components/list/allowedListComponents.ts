export const AllowedListComponents = {
    ListSubtitle: 'ListSubtitle',
    ListSection: 'ListSection',
    ListSections: 'ListSections'
}