import React, { PropsWithChildren } from "react";

export interface ISubtitle extends PropsWithChildren {
	type?: string;
	text?: string;
}

export interface ISections extends PropsWithChildren {}

export interface ISection {
	title: string;
	content: string;
}

export interface IListItemProps extends PropsWithChildren  {
	id?: any;
	imgPath?: string;
	title?: string;
	footer?: string;
	customInfo?: any;
	clickHandler?: (item: IListItemProps, event: React.MouseEvent<HTMLLIElement, MouseEvent>) => void;
	children?: React.ReactNode;
	header?: () => JSX.Element;

}
export interface ListProps extends PropsWithChildren {
	className?: string;
}