import React, { FunctionComponent } from 'react';
import { ListProps } from './list.component.models';

const List: FunctionComponent<ListProps> = (props: ListProps): JSX.Element =>{
	return (
		<>
			<div className={`list-container ${props.className || ''}`}>
				<ul className="card-list">
					{props.children}
				</ul>
			</div>
		</>
	);
}

export default List;