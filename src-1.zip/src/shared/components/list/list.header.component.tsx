import React, { PropsWithChildren } from 'react';
function ListHeader(props: PropsWithChildren): JSX.Element {
	return (
		<div className="card-header card-header-row">
            {props.children}
        </div>
	);
}

export default ListHeader;