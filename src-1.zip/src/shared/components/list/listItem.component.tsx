import React from 'react';
import { IListItemProps } from './list.component.models';
import { AllowedListComponents } from './allowedListComponents';
import ListHeader from './list.header.component';

function ListItem(props: IListItemProps): JSX.Element {
	const clickableCls = props.clickHandler ? 'clickable' : '';
	const isAnyInvalidChild = React.Children.toArray(props.children).some((child: any) => {
		let allowedList = Object.keys(AllowedListComponents);
		return !allowedList.includes(child.props.__type);
	});

	try {
		if (isAnyInvalidChild) {
			throw new Error('Invalid component used in list component. Please use ListSubtitle, ListSections or ListSection');
		}
	} catch (error) {
		console.error(error);
	}

	const item: IListItemProps = {
		id: props.id, imgPath: props.imgPath, title: props.title, footer: props.footer, customInfo: props.customInfo
	};

	const itemClickHandler = (e: any): void => {
		if (props.clickHandler) {
			props.clickHandler(item, e);
		}
	};

	return (
		<li onClick={itemClickHandler} className={`card-list-item ${clickableCls}`}>
			<div className="card">
				{props.header && (<ListHeader>{props.header()}</ListHeader>)}
				<div className="card-body card-body-row">
					<div className='card-img-container'>
						<div className='card-img'>
							<img className='img-fluid' src={`${props.imgPath || ''}`} alt="..." />
						</div>
					</div>
					<div className="card-content">
						<h6 className="card-title">{props.title}</h6>
						{props.children}
					</div>
				</div>
				{props.footer && <div className="card-footer" title="Footer">
					{props.footer}
				</div>}
			</div>
		</li>
	);
}

ListItem.defaultProps = {
	_type: 'ListItem',
};

export default ListItem;