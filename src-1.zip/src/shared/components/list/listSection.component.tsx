import React from 'react';
import { ISection } from './list.component.models';
import { AllowedListComponents } from './allowedListComponents';

function ListSection({ title, content }: ISection): JSX.Element {
	return (
		<>
			<div className='col'>
				<div className='card-text'>
					<div>{title}</div>
					<div>{content}</div>
				</div>
			</div>
		</>
	);
}

ListSection.defaultProps = {
	__type: AllowedListComponents.ListSection
};

export default ListSection;