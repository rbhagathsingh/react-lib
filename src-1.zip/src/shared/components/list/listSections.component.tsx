import React from 'react';
import { ISections } from './list.component.models';
import { AllowedListComponents } from './allowedListComponents';	

function ListSections({ children }: ISections): JSX.Element {
	const isAnyInvalidChild = React.Children.toArray(children).some((child: any) => {
		let allowedList = Object.keys(AllowedListComponents);
		return !allowedList.includes(child.props.__type);
	});
	try {
		if (isAnyInvalidChild) {
			throw new Error('Invalid component used in list component. Please use ListSubtitle, ListSections or ListSection');
		}
	} catch (error) {
		console.error(error);
	}

	return (
		<>
			<div className='row'>
				{children}
			</div>
		</>
	);
}

ListSections.defaultProps = {
	__type: AllowedListComponents.ListSections
};

export default ListSections;