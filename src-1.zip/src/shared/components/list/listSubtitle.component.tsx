import React, { FunctionComponent } from 'react';
import { ISubtitle } from './list.component.models';
import { AllowedListComponents } from './allowedListComponents';

const ListSubtitle: FunctionComponent = ({ type, text, children }: ISubtitle): JSX.Element => {
	const mutedCls = type === 'muted' ? 'text-muted' : '';
	return (
		<div className={`card-text ${mutedCls}`} title={text}>{text}{children}</div>
	);
}

ListSubtitle.defaultProps = {
	__type: AllowedListComponents.ListSubtitle
};

export default ListSubtitle;