import React from 'react';

function Preloader(props: {className?: string, size?: number | string}): JSX.Element {
	return (
		<div className={`inline-preloader-block ${props.className || ''} size-${props.size || 'auto'}`}>
			<span>
				<img src={process.env.PUBLIC_URL + '/assets/images/preloader.gif'}/>
			</span>
		</div>
	);
}

export default Preloader;