
class PreloaderController {
    public static preloaderObj: {[key: string]: any} = {};

    public static preloaderData: any[] = [];

    public static open(opt?: any): void {
        this.preloaderData[this.preloaderData.length] = true;
        const defaultOptions = Object.assign({
            container: document.body
        }, opt || {});

        const container = typeof defaultOptions.container === 'string' ? document.querySelector(defaultOptions.container) : defaultOptions.container;

        const preloader: HTMLDivElement | null = document.querySelector('.app-preloader');
        if (preloader) {
            preloader.style.display = 'flex';
            setTimeout(() => {
                preloader?.classList.add('opend');
            }, 30);
        } else if (!preloader) {
            let ele: any = null;
            ele = document.createElement('div');
            ele.classList.add('app-preloader');
            ele.innerHTML = `
                <div class="app-preloader-block">
                    <span class="preloader-icon">
                        <img src="/assets/images/Loading-animation-white-250.gif">
                    </span>
                    <span>Loading...</span>
                </div>
            `;
            container.appendChild(ele);
            setTimeout(() => {
                ele.classList.add('opend');
            }, 30);
        }
    }

    public static close(): void {
        if (this.preloaderData.length > 0) {
            this.preloaderData.splice(0, 1);
        }
        if (this.preloaderData.length === 0) {
            const preloader: any = document.querySelector('.app-preloader');
            if (preloader) {
                setTimeout(() => {
                    preloader.style.display = 'none';
                }, 300);
                preloader.classList.remove('opend');
            }
        }
    }
}

export default PreloaderController;