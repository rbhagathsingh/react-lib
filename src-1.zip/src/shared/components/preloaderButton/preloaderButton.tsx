import React, { Fragment, FunctionComponent, useState } from 'react';
import Preloader from '../preloader/preloader.component';

export interface LoadingButtonProps {
    className?: string;
    onClick?: (evt?: React.MouseEvent<HTMLButtonElement, MouseEvent>) => void;
    variant?: 'primary' | 'secondary';
    type?: 'submit' | 'button';
    disabled?: boolean;
    isLoading?: boolean;
    name: string;
    size?: 'block' | 'normal'
}
const PreloaderButton: FunctionComponent<LoadingButtonProps> = ({ className, onClick, variant, type, isLoading, size, name }): JSX.Element => {
    const [buttonStates] = useState({
        variant: variant || 'primary',
        type: type || 'button',
    });
    const buttonClick = (evt: React.MouseEvent<HTMLButtonElement, MouseEvent>): void => {
        if (onClick) {
            onClick(evt);
        }
    };

    return (
	<Fragment>
		{!isLoading && (
		<button className={`btn pp-btn-${buttonStates.variant} pp-btn-${size || 'normal'} ${(className || '')}`} type={buttonStates.type} onClick={buttonClick}>{name}</button>
            )}
		{isLoading && (
		<button className={`preloader-btn btn pp-btn-${buttonStates.variant} pp-btn-${size || 'normal'} ${(className || '')}`} type="button">
			<span className="btn-txt">{name}</span> <Preloader></Preloader>
		</button>
            )}
	</Fragment>
    );
};

export default PreloaderButton;