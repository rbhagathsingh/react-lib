const APISet = {
    getShippingAddress: {
        url: '/users/[userId]/shipping-address',
        method: 'GET'
    },
    setShippingAddress: {
        url: '/users/[userId]/save-shipping-address',
        method: 'POST'
    }
}

export default APISet;