const GenericStorageConstants = {
    LoginEmail: 'email',
    Token: 'auth_token',
    IpInfo: 'ipinfo',
    UserData: 'userData',
    UserId: 'userId'
}

export default GenericStorageConstants;