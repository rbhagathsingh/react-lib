export const RegExp = {
	Email: /((^[a-zA-Z\-\][\w.+]+@(proofpilot|cyclogram)\.com$)|(^([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5})$))/,
	Phone: /^\+?\d{8,20}$/,
	Password: /^[a-zA-Z0-9!@#\$%\^\&*\)\(+=._-]{8,}$/
};
