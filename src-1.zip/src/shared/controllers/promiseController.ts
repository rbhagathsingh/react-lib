class PromiseController<T> {
    public result: Promise<T>;
    private _resolve;
    private _reject;
    constructor() {
        this.result = new Promise((resolve, reject) => {
            this._resolve = resolve;
            this._reject = reject;
        });
    }
    public resolve(data?: T) {
        this._resolve(data)
    }
    public reject(data?: T) {
        this._reject(data)
    }
}

export default PromiseController;