const cancellablePromise = (promise: Promise<any>): object => {
    const isCancelled = { value: false };
    const wrappedPromise = new Promise((resolve, reject) => {
        promise
            .then(d => {
                return isCancelled.value ? reject(isCancelled) : resolve(d);
            })
            .catch(error => {
							reject(isCancelled.value ? isCancelled : error);
            });
    });

    return {
        promise: wrappedPromise,
        cancel: () => {
            isCancelled.value = true;
        }
    };
};

export default cancellablePromise;