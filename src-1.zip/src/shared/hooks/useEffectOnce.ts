import { useEffect, useRef, useState } from "react";

const useEffectOnce = (effect: () => void): void => {
    const destroyFunc = useRef<any>();
    const effectCalled = useRef(false);
    const renderAfterCalled = useRef(false);
    const [, setVal] = useState(0);
  
    if (effectCalled.current) {
        renderAfterCalled.current = true;
    }
  
    useEffect(() => {
        // only execute the effect first time around
        if (!effectCalled.current) { 
          destroyFunc.current = effect();
          effectCalled.current = true;
        }
  
        // this forces one render after the effect is run
        setVal(res => res + 1);
  
        return () => {
          if (!renderAfterCalled.current) { return; }
          if (destroyFunc.current) { console.log('dist======'); destroyFunc.current(); }
        };
    }, []);
};

export default useEffectOnce;