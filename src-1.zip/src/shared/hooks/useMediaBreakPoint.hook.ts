import {  useState } from 'react';
import { useEventListener, useIsomorphicLayoutEffect } from 'usehooks-ts';
interface MediaBreakPointProps {
    width: number; 
    breakPoint: 'xs' | 'sm' | 'md' | 'lg' | 'xl' | 'xxl'
}
const useMediaBreakPoint = (): MediaBreakPointProps => {
    const [breakPoint, setBreakPoint] = useState<MediaBreakPointProps>({
        width: 0,
        breakPoint: 'xs'
    });

    const handleSize = (): void => {
        const wW = window.innerWidth;
        let brPoint: any = 'xxl';
        if(wW >= 0 && wW < 576) {
            brPoint = 'xs'
        } else if(wW >= 576 && wW < 768) {
            brPoint = 'sm'
        }else if(wW >= 768 && wW < 992) {
            brPoint = 'md'
        }else if(wW >= 992 && wW < 1200) {
            brPoint = 'lg'
        }else if(wW >= 1200 && wW < 1400) {
            brPoint = 'xl'
        }else if(wW >= 1400) {
            brPoint = 'xxl'
        }
        
        setBreakPoint({
            width: wW,
            breakPoint: brPoint
        });
    }
    useEventListener('resize', handleSize)
    useIsomorphicLayoutEffect(() => {
        handleSize()
    }, [])
    
    return breakPoint;
}

export default useMediaBreakPoint;