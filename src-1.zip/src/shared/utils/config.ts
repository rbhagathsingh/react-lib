interface configs {
    language?: string
}
class Config {
    public static configs: configs = {
        language: ''
    };

    public static setConfigs({ language }: configs): void {
        if (!Object.isFrozen(this.configs)) {
            this.configs.language = language;
            Object.freeze(this.configs);
        }
    }
}

export default Config;