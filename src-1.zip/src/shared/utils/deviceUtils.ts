import { PromiseController } from "shared/controllers";

class DeviceUtils {
    public static isIOSDevice(){
        return !!navigator.platform && /iPad|iPhone|iPod/.test(navigator.platform);
    }
    public static isSafari(){
        return /^((?!chrome|android).)*safari/i.test(navigator.userAgent);
    }

    public static getOS() {
        let userAgent = window.navigator.userAgent,
            platform = window.navigator.platform,
            macosPlatforms = ['Macintosh', 'MacIntel', 'MacPPC', 'Mac68K'],
            windowsPlatforms = ['Win32', 'Win64', 'Windows', 'WinCE'],
            iosPlatforms = ['iPhone', 'iPad', 'iPod'],
            os:string | null = null;
      
        if (macosPlatforms.indexOf(platform) !== -1) {
          os = 'Mac OS';
        } else if (iosPlatforms.indexOf(platform) !== -1) {
          os = 'iOS';
        } else if (windowsPlatforms.indexOf(platform) !== -1) {
          os = 'Windows';
        } else if (/Android/.test(userAgent)) {
          os = 'Android';
        } else if (!os && /Linux/.test(platform)) {
          os = 'Linux';
        }
      
        return os;
    }

    public static getGeolocation(): Promise<any> {
      const promise = new PromiseController();
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition((res) => {
          promise.resolve(res);
        }, (error) => {
          promise.reject(error);
        });
      }else {
        promise.reject({
          error: 'Geolocation is not supported by this browser.'
        });
      }
     
      return promise.result;
    }
}
export default DeviceUtils;