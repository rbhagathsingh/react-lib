
class MediaUtils {
    public static getUserMedia(options?: MediaStreamConstraints): Promise<MediaStream> {
        return navigator.mediaDevices.getUserMedia({video:true});
    }
    public static enumerateDevices(): Promise<MediaDeviceInfo[]> {
        return navigator.mediaDevices.enumerateDevices();
    }
}
export default MediaUtils;