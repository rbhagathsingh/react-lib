import _ from 'lodash';

interface ObjectKeyPair {
	[key: string]: any;
}
type MapString = [string, any];
class Utils {
    private static _storagePrifix: string = '';
    private static timerObject: any = {};
    
    public static toJson(val: any): any {
        return val ? JSON.parse(val) : val;
    }

    public static toString(val: any): string {
        return val ? JSON.stringify(val) : val;
    }

    public static timeout(key: string, callBack: () => void, time = 100): void {
        this.timerObject[key] = setTimeout(callBack, time);
    }

    public static clearTimeout(key: string): void {
        if (this.timerObject[key] !== undefined) {
            clearTimeout(this.timerObject[key]);
            delete this.timerObject[key];
        }
    }

    public static replace(url: string, str: string, val: string): string {
        return url.replace(str, val);
    }

    public static isArray(val: any): boolean {
        return Object.prototype.toString.call(val) === '[object Array]';
    }

    public static isObject(val: any): boolean {
        return Object.prototype.toString.call(val) === '[object Object]';
    }

    public static trimDoubleQuote(url: string){
        return url.replaceAll('"', "");
    }

    public static eachKeyValue(obj: ObjectKeyPair, callBack: (value?: string, key?: any, object?: ObjectKeyPair) => any): void {
			if (!obj || !this.isObject(obj)) {
				throw new Error('Object is not valid');
			}
			for (const key in obj) {
				callBack(obj[key], key, obj);
			}
    }

    public static getQueryData(url: string, obj: URLSearchParams) {
        let urlData = url.split('?');
        let urlStr: string[] = urlData.length > 1 ? urlData[1].split('&'): [];
        return urlStr.reduce((x: any, ele: string) => {
            let query = ele.split('=');
            x = x || {};
            x[query[0]] = obj.get(query[0]);
            return x;
        }, null)
    }

    public static getReferralHash(data: any) {
        return encodeURIComponent(btoa(JSON.stringify(data)));
    }

    public static getRejectionMessage(rejection: any) {
        var message = rejection;
        if (rejection.data) {
            const error = typeof rejection.data === 'string' ?  this.toJson(rejection.data) : rejection.data;
            if (error.description) {
                return error.description;
            }
            if (error.message) {
                return error.message;
            }
            if (error.error_description) {
                return error.error_description;
            }
            if (error.errors) {
                if(error.errors.title) {
                    return error.errors.title[0];
                }
                return _.flatten(_.values(error.errors)).join('\n');
            }
            if (error.error) {
                message = error.error.message || error.error;
            } else {
                message = error;
            }
        } else {
            if (rejection.description) {
                message = rejection.description;
            } else if (rejection.message) {
                message = rejection.message;
            } else if (rejection.config && rejection.config.url) {
                message = 'Error requesting "' + rejection.config.url +
                  '" on page "' + window.location.href + '"';
            } else {
                message = this.toString(rejection);
            }
        }
        return message;
    }
    
    public static mediaBreakPoints(callBack: (val: {width: number; breakPoint: 'xs' | 'sm' | 'md' | 'lg' | 'xl' | 'xxl'}) => void) {
        function resizeCallBack() {
            const wW = window.innerWidth;
            let brPoint: any = 'xxl';
            if(wW >= 0 && wW < 576) {
                brPoint = 'xs'
            } else if(wW >= 576 && wW < 768) {
                brPoint = 'sm'
            }else if(wW >= 768 && wW < 992) {
                brPoint = 'md'
            }else if(wW >= 992 && wW < 1200) {
                brPoint = 'lg'
            }else if(wW >= 1200 && wW < 1400) {
                brPoint = 'xl'
            }else if(wW >= 1400) {
                brPoint = 'xxl'
            }
            callBack({
                width: wW,
                breakPoint: brPoint
            });
        }
        window.addEventListener('resize', resizeCallBack);
        return {
            off: () => {
                window.removeEventListener('resize', resizeCallBack);
            }
        }
    }

    public static mapURIs(url: string, arr: MapString[]) {
        let str = url;
        arr.forEach((ele, ind) => {
            str = this.replace(str, ele[0], ele[1]);
        });
        return str;
    }

    public static getLocalStore(key: string): any {
        const store = localStorage.getItem(`${this._storagePrifix}${key}`);
        return store ? this.toJson(store) : store;
    }

    public static clearAllLocalStore(): void {
        localStorage.clear();
    }

    public static removeLocalStore(key: string): void {
        localStorage.removeItem(`${this._storagePrifix}${key}`);
    }

    public static getSessionStore(key: string): any {
        const store = sessionStorage.getItem(`${this._storagePrifix}${key}`);
        return store ? this.toJson(store) : store;
    }

    public static clearAllSessionStore(): void {
        sessionStorage.clear();
    }

    public static removeSessionStore(key: string): void {
        sessionStorage.removeItem(`${this._storagePrifix}${key}`);
    }
    
}
export default Utils;